import java.awt.*;

public class ConcentricSquares extends Canvas {

    private void drawSquares(Graphics2D g, double x, double y, double size, int depth) {
        if (depth == 0) return;

        double half = size / 2.0;
        int[] xDiamond = {(int) x, (int) (x + half / 2), (int) x, (int) (x - half / 2)};
        int[] yDiamond = {(int) (y - half / 2), (int) y, (int) (y + half / 2), (int) y};
        g.drawPolygon(xDiamond, yDiamond, 4);

        if (depth < 6) { 
            int[] xSquare = {(int) (x - half), (int) (x + half), (int) (x + half), (int) (x - half)};
            int[] ySquare = {(int) (y - half), (int) (y - half), (int) (y + half), (int) (y + half)};
            g.drawPolygon(xSquare, ySquare, 4);
        }

        drawSquares(g, x, y, half, depth - 1);
    }

    @Override
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int size = Math.min(getWidth(), getHeight());
        g2d.translate(getWidth() / 2.0, getHeight() / 2.0);
        g2d.scale(size / 400.0, size / 400.0);
        drawSquares(g2d, 0, 0, 200, 6);
    }

    public static void main(String[] args) {
        Frame frame = new Frame("Concentric Squares");
        ConcentricSquares canvas = new ConcentricSquares();
        frame.add(canvas);
        frame.setSize(500, 500);
        frame.setVisible(true);

        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
