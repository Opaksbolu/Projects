#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX_N 100

int N, M;
int MA[MAX_N][MAX_N], MB[MAX_N][MAX_N], MC[MAX_N][MAX_N];
pthread_mutex_t lock;
int diagonal_sum = 0;

void *matrix_multiply(void *arg) {
    int thread_id = *((int *)arg);
        int start_col = N / M * thread_id;
	    int end_col = N / M * (thread_id + 1);

	        int i, j, k;
		    for (i = 0; i < N; i++) {
		            for (j = start_col; j < end_col; j++) {
			                int sum = 0;
					            for (k = 0; k < N; k++) {
						                    sum += MA[i][k] * MB[k][j];
								                }

										            pthread_mutex_lock(&lock);
											                MC[i][j] = sum;
													            diagonal_sum += (i == j) ? sum : 0;
														                printf("Thread %d updates MC(%d,%d) set to be %d\n", thread_id, i, j, sum);
																            pthread_mutex_unlock(&lock);
																	            }
																		        }

																			    return NULL;
																			    }

																			    int main(int argc, char *argv[]) {
																			        if (argc != 3) {
																				        printf("Usage: %s N M\n", argv[0]);
																					        return 1;
																						    }

																						        N = atoi(argv[1]);
																							    M = atoi(argv[2]);

																							        if (N % M != 0 || N < M) {
																								        printf("Invalid input. N must be a multiple of M and N >= M.\n");
																									        return 1;
																										    }

																										        pthread_t threads[M];
																											    int thread_ids[M];

																											        pthread_mutex_init(&lock, NULL);

																												    int i, j;
																												        for (i = 0; i < N; i++) {
																													        for (j = 0; j < N; j++) {
																														            MA[i][j] = 1;  // Initialize MA and MB with suitable values
																															                MB[i][j] = 2;
																																	        }
																																		    }

																																		        for (i = 0; i < M; i++) {
																																			        thread_ids[i] = i;
																																				        pthread_create(&threads[i], NULL, matrix_multiply, &thread_ids[i]);
																																					    }

																																					        for (i = 0; i < M; i++) {
																																						        pthread_join(threads[i], NULL);
																																							    }

																																							        pthread_mutex_destroy(&lock);

																																								    printf("Diagonal sum of MC: %d\n", diagonal_sum);

																																								        system("date; hostname; who | grep abo200001; ps -eaf; ls -l ");
																																									    system("who > week10who.txt");

																																									        return 0;
																																										}

