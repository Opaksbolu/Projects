Bank Simulation (Python) - macOS

Overview
This Python application simulates a bank with:
- 3 Teller threads
- 50 Customer threads
- Shared resources controlled by semaphores:
  - Manager (1 teller at a time)
  - Safe (2 tellers at a time)
  - Door (2 customers at a time)

Customers randomly choose to deposit or withdraw. Tellers handle transactions, including manager approvals (for withdrawals) and accessing the safe.

Requirements
- Python 3.x (tested on macOS)
- Basic familiarity with concurrency (threading, locks, semaphores)

Setup & Usage
1. Clone or Download the project from Git (if you have a remote) or place `bank_simulation.py` in a local folder.
2. Install Python 3 if not already on your Mac.
3. Open Terminal and navigate to the project folder:
   ```bash
   cd /path/to/CS4348_Project2
4. Run the simulation:
python3 bank_simulation.py

