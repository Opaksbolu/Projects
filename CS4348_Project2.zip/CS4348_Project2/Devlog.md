DevLog - Python Bank Simulation

Monday 7th April 2025
- Worked on the coding to be tested.
- Made sure to test it out on Visual studio first to make sure it ran properly.
- The other way was to try running it through the cs1 server using global connect and testing it there before trying it to the main file to run.


Wednesday 9th April 2025 
- Created Project Folder: Initialized a new folder `CS4348_Project2`.
- Initialized Git: Ran `git init` to start version control.
- Set Up bank_simulation.py:
  - Created basic file structure using `threading` and `time`.
  - Defined semaphores for safe (2 max) and manager (1 max), as well as door (2 max).
  - Printed minimal lines for teller and customer threads.
- Refined Thread Synchronization:
  - Added condition variables to handle teller availability.
  - Ensured customers queue properly if no teller is available.
  - Added random sleep ranges as specified (e.g., 5–30 ms for manager, 10–50 ms in safe).
- Final Testing & Debugging:
  - Ran with smaller customer sets (5–10) to test synchronization and logs.
  - Fixed print statements to match project guidelines exactly.
  - Confirmed final run with 50 customers, ensuring no deadlocks or missed prints.
  - Committed code with `git commit -m "Final version for Python bank simulation"`.

Thursday 10th April 2025
- Tested the code once more to check if it runs properly

Friday 11th April 2025
- Finished the Devlog file and ReadMe file for upload. 