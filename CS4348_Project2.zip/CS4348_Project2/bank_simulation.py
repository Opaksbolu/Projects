import threading
import time
import random
from collections import deque

# ---------------------------
# Adjustable simulation parameters
# ---------------------------
NUM_TELLERS = 3
NUM_CUSTOMERS = 50

# ---------------------------
# Semaphore-based concurrency limits
# ---------------------------

# Only 2 customers can enter the bank at once
door_sem = threading.Semaphore(2)

# Only 2 tellers can be in the safe at once
safe_sem = threading.Semaphore(2)

# Only 1 teller at a time can interact with the manager (for withdrawals)
manager_sem = threading.Semaphore(1)

# ---------------------------
# Shared counters and locks
# ---------------------------

# Track how many customers have fully completed their transactions
customers_served = 0
customers_served_lock = threading.Lock()

def all_customers_served():
    """Check if all customers have been served."""
    with customers_served_lock:
        return (customers_served >= NUM_CUSTOMERS)

# ---------------------------
# Customer Waiting Line
# ---------------------------
# A queue to hold customers waiting for an available teller.
waiting_line = deque()

# We'll lock this queue so multiple threads (Tellers & Customers) can safely operate on it.
waiting_line_lock = threading.Lock()

# Condition variable: Tellers wait on it if the line is empty, customers notify it when they join.
line_not_empty = threading.Condition(waiting_line_lock)

# ---------------------------
# Utility function for random sleeps in milliseconds
# ---------------------------
def random_sleep_ms(min_ms, max_ms):
    """Sleep for a random time between min_ms and max_ms milliseconds."""
    sleep_time = random.randint(min_ms, max_ms)
    time.sleep(sleep_time / 1000.0)

# ---------------------------
# Customer Class (Thread)
# ---------------------------
class Customer(threading.Thread):
    def __init__(self, customer_id):
        super().__init__()
        self.customer_id = customer_id
        # Decide if this customer will do a deposit or withdrawal
        self.is_withdrawal = bool(random.getrandbits(1))
        # An Event that the Teller sets to let the customer know the transaction is done
        self.done_event = threading.Event()

    def run(self):
        transaction_type = "withdrawal" if self.is_withdrawal else "deposit"
        print(f"Customer {self.customer_id} []: wants to perform a {transaction_type} transaction")

        # Simulate random delay before going to the bank (0–100 ms)
        random_sleep_ms(0, 100)

        # Enter the bank (max 2 customers at once)
        door_sem.acquire()
        print(f"Customer {self.customer_id} []: entering bank")

        # Join the waiting line
        with waiting_line_lock:
            print(f"Customer {self.customer_id} []: getting in line")
            waiting_line.append(self)
            # Let any waiting Teller know a new customer is available
            line_not_empty.notify()

        # Wait until the Teller finishes our transaction (the Teller will .set() our done_event)
        self.done_event.wait()

        # Leave the bank
        print(f"Customer {self.customer_id} []: leaving bank")
        door_sem.release()

        # Mark this customer as served
        global customers_served
        with customers_served_lock:
            customers_served += 1

# ---------------------------
# Teller Class (Thread)
# ---------------------------
class Teller(threading.Thread):
    def __init__(self, teller_id):
        super().__init__()
        self.teller_id = teller_id

    def run(self):
        print(f"Teller {self.teller_id} []: ready to serve")

        while True:
            # If all customers are served, teller can exit
            if all_customers_served():
                print(f"Teller {self.teller_id} []: no more customers to serve, teller closing.")
                return

            # Attempt to get the next customer in the waiting line
            with waiting_line_lock:
                while not waiting_line and not all_customers_served():
                    # No customers at the moment—wait until one arrives
                    print(f"Teller {self.teller_id} []: waiting for a customer")
                    line_not_empty.wait()

                # If line is still empty but all customers done, teller closes
                if not waiting_line and all_customers_served():
                    print(f"Teller {self.teller_id} []: no more customers to serve, teller closing.")
                    return

                # Otherwise, we have a customer to serve
                customer = waiting_line.popleft()

            # Serve the customer
            print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: serving this customer")

            if customer.is_withdrawal:
                print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: asks for withdrawal transaction")
                print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: going to manager")
                # Acquire manager semaphore
                manager_sem.acquire()
                print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: interacting with manager")
                random_sleep_ms(5, 30)  # 5–30 ms manager approval
                print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: done with manager")
                manager_sem.release()
            else:
                print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: asks for deposit transaction")

            # Go to safe
            print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: going to safe")
            safe_sem.acquire()
            print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: in the safe")
            random_sleep_ms(10, 50)   # 10–50 ms in the safe
            print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: leaving safe")
            safe_sem.release()

            print(f"Teller {self.teller_id} [Customer {customer.customer_id}]: transaction complete")

            # Notify customer transaction is done
            customer.done_event.set()

# ---------------------------
# Main function
# ---------------------------
def main():
    # Create and start Teller threads
    tellers = [Teller(t_id) for t_id in range(NUM_TELLERS)]
    for t in tellers:
        t.start()

    # Create and start Customer threads
    customers = [Customer(c_id) for c_id in range(NUM_CUSTOMERS)]
    for c in customers:
        c.start()

    # Wait for all customers to finish
    for c in customers:
        c.join()

    # IMPORTANT: At this point, all customers are done. Tellers may be stuck in line_not_empty.wait().
    # We wake them up so they see "all_customers_served()" is True and exit.
    with waiting_line_lock:
        line_not_empty.notify_all()

    # Now let Tellers detect no more customers remain
    for t in tellers:
        t.join()

    print("Bank simulation complete.")

# Entry point
if __name__ == "__main__":
    main()
