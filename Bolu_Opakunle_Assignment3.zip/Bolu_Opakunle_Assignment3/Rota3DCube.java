public class Rota3DCube {
    public static void main(String[] args) {
        if (args.length < 5) {
            System.out.println("Usage: java Rota3DCube <a1> <a2> <a3> <alphaDegrees> <x_axis|y_axis|z_axis>");
            return;
        }

        double a1 = Double.parseDouble(args[0]);
        double a2 = Double.parseDouble(args[1]);
        double a3 = Double.parseDouble(args[2]);
        double alphaDeg = Double.parseDouble(args[3]);
        String principalAxis = args[4];

        double[][] originalVertices = {
            {0,0,0},{1,0,0},{1,0,1},{0,0,1},
            {0,1,1},{1,1,1},{1,1,0},{0,1,0}
        };

        double[][] transformedVertices = new double[originalVertices.length][3];
        for (int i = 0; i < originalVertices.length; i++) {
            transformedVertices[i][0] = originalVertices[i][0];
            transformedVertices[i][1] = originalVertices[i][1];
            transformedVertices[i][2] = originalVertices[i][2];
        }

        System.out.println("--------------------------------------------------");
        System.out.println(" Rotation of unit cube about arbitrary point ("
                           + a1 + ", " + a2 + ", " + a3 + ") by "
                           + alphaDeg + " degrees");
        System.out.println(" Principal axis of rotation: " + principalAxis);
        System.out.println("--------------------------------------------------\n");

        System.out.println("Vertices before rotation:");
        for (int i = 0; i < transformedVertices.length; i++) {
            System.out.printf("Vertex %d: (%.4f, %.4f, %.4f)\n",
                    i, transformedVertices[i][0], transformedVertices[i][1], transformedVertices[i][2]);
        }
        System.out.println();

        // Translate so that (a1, a2, a3) moves to (0, 0, 0)
        for (int i = 0; i < transformedVertices.length; i++) {
            transformedVertices[i][0] -= a1;
            transformedVertices[i][1] -= a2;
            transformedVertices[i][2] -= a3;
        }

        // Convert angle from degrees to radians
        double alphaRad = Math.toRadians(alphaDeg);
        double cos = Math.cos(alphaRad);
        double sin = Math.sin(alphaRad);

        // Build rotation matrix
        double[][] rotationMatrix = new double[3][3];

        if (principalAxis.equalsIgnoreCase("x_axis")) {
            rotationMatrix[0][0] = 1;   rotationMatrix[0][1] = 0;    rotationMatrix[0][2] = 0;
            rotationMatrix[1][0] = 0;   rotationMatrix[1][1] = cos;  rotationMatrix[1][2] = -sin;
            rotationMatrix[2][0] = 0;   rotationMatrix[2][1] = sin;  rotationMatrix[2][2] = cos;
        } else if (principalAxis.equalsIgnoreCase("y_axis")) {
            rotationMatrix[0][0] = cos; rotationMatrix[0][1] = 0;    rotationMatrix[0][2] = sin;
            rotationMatrix[1][0] = 0;   rotationMatrix[1][1] = 1;    rotationMatrix[1][2] = 0;
            rotationMatrix[2][0] = -sin;rotationMatrix[2][1] = 0;    rotationMatrix[2][2] = cos;
        } else if (principalAxis.equalsIgnoreCase("z_axis")) {
            rotationMatrix[0][0] = cos; rotationMatrix[0][1] = -sin; rotationMatrix[0][2] = 0;
            rotationMatrix[1][0] = sin; rotationMatrix[1][1] = cos;  rotationMatrix[1][2] = 0;
            rotationMatrix[2][0] = 0;   rotationMatrix[2][1] = 0;    rotationMatrix[2][2] = 1;
        } else {
            System.out.println("Invalid axis. Use x_axis, y_axis, or z_axis.");
            return;
        }

        // Rotate each vertex
        for (int i = 0; i < transformedVertices.length; i++) {
            double xOld = transformedVertices[i][0];
            double yOld = transformedVertices[i][1];
            double zOld = transformedVertices[i][2];

            double xNew = rotationMatrix[0][0]*xOld + rotationMatrix[0][1]*yOld + rotationMatrix[0][2]*zOld;
            double yNew = rotationMatrix[1][0]*xOld + rotationMatrix[1][1]*yOld + rotationMatrix[1][2]*zOld;
            double zNew = rotationMatrix[2][0]*xOld + rotationMatrix[2][1]*yOld + rotationMatrix[2][2]*zOld;

            transformedVertices[i][0] = xNew;
            transformedVertices[i][1] = yNew;
            transformedVertices[i][2] = zNew;
        }

        // Translate back
        for (int i = 0; i < transformedVertices.length; i++) {
            transformedVertices[i][0] += a1;
            transformedVertices[i][1] += a2;
            transformedVertices[i][2] += a3;
        }

        System.out.println("Vertices after rotation:");
        for (int i = 0; i < transformedVertices.length; i++) {
            System.out.printf("Vertex %d: (%.4f, %.4f, %.4f)\n",
                    i, transformedVertices[i][0], transformedVertices[i][1], transformedVertices[i][2]);
        }
        System.out.println();
    }
}
