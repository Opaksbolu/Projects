import subprocess

process = subprocess.Popen(["python3", "encrypt.py"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)

print("\nDriver Program Testing, type the command you want first and add the content to test after and once complete type quit\n")

history = []

while True:
    cmd = input("Enter command (password/encrypt/decrypt/history/quit): ").strip().lower()
    
    if cmd == "password":
        passkey = input("Enter passkey: ").strip()
        process.stdin.write(f"PASS {passkey}\n")
        process.stdin.flush()
        history.append(f"password (Key set)")

    elif cmd == "encrypt":
        text = input("Enter text to encrypt: ").strip()
        process.stdin.write(f"encrypt {text}\n")
        process.stdin.flush()
        history.append(f"encrypt {text}")

    elif cmd == "decrypt":
        text = input("Enter text to decrypt: ").strip()
        process.stdin.write(f"decrypt {text}\n")
        process.stdin.flush()
        history.append(f"decrypt {text}")

    elif cmd == "history":
        print("\nCommand History:")
        for index, entry in enumerate(history, start=1):
            print(f"{index}. {entry}")
        continue

    elif cmd == "quit":
        process.stdin.write("quit\n")
        process.stdin.flush()
        break

    response = process.stdout.readline().strip()
    print(f"Encryption Program Response: {response}")

