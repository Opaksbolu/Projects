Project Overview

This project consists of three separate programs:

Logger - Logs all activity to a log file.

Encryption Program - Encrypts and decrypts text using a Vigenère cipher.

Driver Program - Acts as the main interface for the user, managing encryption and logging.

The programs communicate using pipes via the Python subprocess module.

Project Structure

driver.py - Main driver program

encrypt.py - Encryption and decryption program

logger.py - Logging program

logfile.txt - Stores log messages

How to Run

Prerequisites

Python 3 installed on your system

Running the Project

Open a terminal or command prompt.

Navigate to the project folder:

cd OS_Project_1

Run the driver program with a log file:

python3 driver.py logfile.txt

Usage

Once the program starts, you will see a menu with the following commands:

password - Set or use a password for encryption.

encrypt - Encrypt a string.

decrypt - Decrypt a string.

history - Show encryption/decryption history.

quit - Exit the program.

Example Interaction

Welcome to the Encryption System!
1. Set password
2. Encrypt
3. Decrypt
4. Show history
5. Quit
Enter your choice: 1
Enter a password: SECRET
RESULT: Password Set

Notes

Input is case insensitive.

Only letters are allowed in passwords and encrypted text.

The logger records all actions with timestamps.

The history of encrypted strings is maintained only for the session.