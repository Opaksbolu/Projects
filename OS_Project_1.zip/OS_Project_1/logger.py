import sys
from datetime import datetime

logfile = sys.argv[1]

with open(logfile, 'a') as log:
    for line in sys.stdin:
        if line.strip() == 'QUIT':
            break
        action, message = line.strip().split(' ', 1)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
        log.write(f"{timestamp} [{action}] {message}\n")

