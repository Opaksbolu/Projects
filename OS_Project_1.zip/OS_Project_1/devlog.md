
Last login: Sun Mar  9 11:27:36 on ttys000
Beginning of the project
abdul-azeemopakunle@abdulazeemsair OS_Project_1 % 
  [Restored Mar 9, 2025 at 9:07:07 PM]
Last login: Sun Mar  9 21:06:59 on console
Restored session: Sun Mar  9 18:19:58 CDT 2025
abdul-azeemopakunle@Abdul-Azeems-MacBook-Air OS_Project_1 % 

  [Restored Mar 10, 2025 at 8:18:23 AM]
Last login: Mon Mar 10 08:18:08 on console
abdul-azeemopakunle@Abdul-Azeems-MacBook-Air OS_Project_1 % 
  [Restored Mar 10, 2025 at 10:04:55 AM]
Last login: Mon Mar 10 10:04:44 on console
Restored session: Mon Mar 10 09:44:28 CDT 2025
abdul-azeemopakunle@Abdul-Azeems-MacBook-Air OS_Project_1 % 
  [Restored Mar 10, 2025 at 10:30:56 AM]
Last login: Mon Mar 10 10:30:46 on console
Restored session: Mon Mar 10 10:30:11 CDT 2025
abdul-azeemopakunle@Abdul-Azeems-MacBook-Air OS_Project_1 % 
  [Restored Mar 11, 2025 at 8:27:29 AM]
Last login: Tue Mar 11 08:27:15 on console
Testing of the code but had errors
Last login: Tue Mar 11 12:40:41 on console
Restored session: Tue Mar 11 12:40:08 CDT 2025
Testing of the program
Last login: Tue Mar 11 12:54:57 on ttys000

made edits to the program
and completed the project