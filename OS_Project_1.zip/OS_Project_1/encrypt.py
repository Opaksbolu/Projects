import sys

passkey = None

while True:
    try:
        command = sys.stdin.readline().strip()
        if not command:
            continue

        if command.startswith("PASS "):
            passkey = command.split(" ", 1)[1]
            print("RESULT Key set", flush=True)

        elif command.startswith("encrypt "):
            if passkey is None:
                print("ERROR No key set", flush=True)
            else:
                text = command.split(" ", 1)[1]
                encrypted_text = ''.join(chr(ord(c) + 1) for c in text)  # Simple encryption
                print(f"RESULT {encrypted_text}", flush=True)

        elif command.startswith("decrypt "):
            if passkey is None:
                print("ERROR No key set", flush=True)
            else:
                text = command.split(" ", 1)[1]
                decrypted_text = ''.join(chr(ord(c) - 1) for c in text)  # Simple decryption
                print(f"RESULT {decrypted_text}", flush=True)

        elif command == "quit":
            print("RESULT Exiting", flush=True)
            break

        else:
            print("ERROR Invalid command", flush=True)

    except Exception as e:
        print(f"ERROR {str(e)}", flush=True)

