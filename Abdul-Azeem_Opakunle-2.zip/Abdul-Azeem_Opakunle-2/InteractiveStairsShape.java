import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * InteractiveStairsShape
 *
 * Generates ascending steps in 3D (straight if alpha=0, or spiral if alpha>0),
 * then displays them in a new window with simple hidden-surface drawing and
 * mouse-drag rotation (the shape is the focus, color is minimal).
 *
 * Usage:
 *   java InteractiveStairsShape <n> <tread> <rise> <width> <alpha>
 *
 * Where:
 *   n      = number of steps
 *   tread  = front-to-back depth of each step
 *   rise   = height of each step
 *   width  = side-to-side width of each step
 *   alpha  = rotation in degrees about z-axis between consecutive steps
 *
 * Example:
 *   1) Straight (connected) 5-step staircase:
 *      java InteractiveStairsShape 5 1 0.2 2 0
 *
 *   2) Spiral: 10 steps, each turned 15°:
 *      java InteractiveStairsShape 10 1 0.2 2 15
 *
 * Adjust the geometry to get the shape you want. Click & drag to rotate.
 */
public class InteractiveStairsShape extends JFrame {

    // ------------------- Data Structures --------------------

    // A point in 3D
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z){
            this.x = x; 
            this.y = y; 
            this.z = z;
        }
    }

    // A polygon (face) with multiple vertices
    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }

    // We store each rectangular step's faces in this list
    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // ------------------- 3D Rendering Settings --------------------

    // Mouse-drag rotates the whole shape:
    private double rotateXDeg = 0.0;  
    private double rotateYDeg = 0.0;

    // Simple perspective projection
    private double cameraDist = 60.0; 
    private double scale      = 6.0;  

    // Optional shift of entire model (not usually needed)
    private double shiftX=0, shiftY=0, shiftZ=0;

    // We'll do a simple fill so faces appear "solid," but keep it neutral.
    private Color stepColor = Color.LIGHT_GRAY; // or Color.GRAY, etc.

    // Mouse drag state
    private int lastMouseX, lastMouseY;

    // ------------------- Constructor --------------------
    public InteractiveStairsShape(int n, double tread, double rise, double width, double alphaDeg) {
        super("Interactive 3D Stairs (Shape Focus) - n="+n+
              " tread="+tread+" rise="+rise+" width="+width+" alpha="+alphaDeg);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Build the 3D polygons for the staircase
        generateStairs(n, tread, rise, width, alphaDeg);

        // Mouse listeners to rotate
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastMouseX = e.getX();
                lastMouseY = e.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;
                lastMouseX = e.getX();
                lastMouseY = e.getY();

                // Horizontal drag changes rotateYDeg
                rotateYDeg += dx * 0.5;
                // Vertical drag changes rotateXDeg
                rotateXDeg += dy * 0.5;
                repaint();
            }
        });

        setVisible(true);
    }

    // ------------------- Stair Generation --------------------
    /**
     * generateStairs:
     *   Creates n rectangular blocks, each from (0,0,0) to (width, tread, rise).
     *   Each block is rotated about Z by 'currentAngle', then offset forward & up.
     *   alphaDeg=0 => straight, alphaDeg>0 => spiral/curved.
     */
    private void generateStairs(int n, double tread, double rise, double width, double alphaDeg) {
        double currentAngleDeg = 0.0;
        double offsetX = 0.0, offsetY = 0.0, offsetZ = 0.0;

        for(int i=0; i<n; i++){
            double radians = Math.toRadians(currentAngleDeg);

            // Local coords of one "step" block (8 corners)
            double[][] c = {
                {0,     0,      0},
                {width, 0,      0},
                {width, tread,  0},
                {0,     tread,  0},
                {0,     0,      rise},
                {width, 0,      rise},
                {width, tread,  rise},
                {0,     tread,  rise}
            };

            // Rotate around z, then add offset
            for(int idx=0; idx<8; idx++){
                double xx = c[idx][0];
                double yy = c[idx][1];
                double zz = c[idx][2];

                double xRot = xx*Math.cos(radians) - yy*Math.sin(radians);
                double yRot = xx*Math.sin(radians) + yy*Math.cos(radians);

                c[idx][0] = xRot + offsetX;
                c[idx][1] = yRot + offsetY;
                c[idx][2] = zz    + offsetZ;
            }

            // 6 faces of the block
            addQuad(c[0], c[1], c[2], c[3]); // bottom
            addQuad(c[4], c[5], c[6], c[7]); // top
            addQuad(c[0], c[1], c[5], c[4]); // front
            addQuad(c[3], c[2], c[6], c[7]); // back
            addQuad(c[1], c[2], c[6], c[5]); // right
            addQuad(c[0], c[3], c[7], c[4]); // left

            // Next step
            currentAngleDeg += alphaDeg;
            // Move forward in local coords by 'tread', up by 'rise'
            double dxLocal = 0;
            double dyLocal = tread;

            double dxWorld = dxLocal*Math.cos(radians) - dyLocal*Math.sin(radians);
            double dyWorld = dxLocal*Math.sin(radians) + dyLocal*Math.cos(radians);

            offsetX += dxWorld;
            offsetY += dyWorld;
            offsetZ += rise;
        }
    }

    // Helper to add a 4-vertex polygon to polygons list
    private void addQuad(double[] v1, double[] v2, double[] v3, double[] v4){
        Polygon3D poly = new Polygon3D();
        poly.verts.add(new Point3D(v1[0], v1[1], v1[2]));
        poly.verts.add(new Point3D(v2[0], v2[1], v2[2]));
        poly.verts.add(new Point3D(v3[0], v3[1], v3[2]));
        poly.verts.add(new Point3D(v4[0], v4[1], v4[2]));
        polygons.add(poly);
    }

    // ------------------- Painting (Hidden-Surface via Z-Sort) --------------------

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth(), h = getHeight();

        // We'll do a naive "z-sort" by average polygon depth
        class PolyZ {
            Polygon3D poly;
            double zavg;
            PolyZ(Polygon3D p, double z){ poly=p; zavg=z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();

        for(Polygon3D poly : polygons){
            double sumZ = 0;
            for(Point3D pt : poly.verts){
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }

        // Sort descending so the farthest polygons are drawn first
        sorted.sort((a,b)->Double.compare(b.zavg, a.zavg));

        // Fill + outline each polygon
        Graphics2D g2 = (Graphics2D)g;
        for(PolyZ pz : sorted){
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D p3 = transform(poly.verts.get(i));
                Point p2 = project(p3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            // Fill with neutral color
            g2.setColor(stepColor);
            g2.fillPolygon(xp, yp, n);

            // Draw edges in black
            g2.setColor(Color.black);
            g2.drawPolygon(xp, yp, n);
        }
    }

    // transform: apply rotateX, rotateY, then scale, ignoring shift for now
    private Point3D transform(Point3D p){
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        // rotate about X
        double rx = Math.toRadians(rotateXDeg);
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double y1 = cx*y0 - sx*z0;
        double z1 = sx*y0 + cx*z0;
        double x1 = x0;

        // rotate about Y
        double ry = Math.toRadians(rotateYDeg);
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double z2 = cy*z1 - sy*x1;
        double x2 = sy*z1 + cy*x1;
        double y2 = y1;

        // scale
        x2 *= scale;
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    // perspective projection
    private Point project(Point3D p, int width, int height){
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0; 
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    // ------------------- MAIN --------------------
    public static void main(String[] args){
        if(args.length < 5){
            System.out.println("Usage: java InteractiveStairsShape <n> <tread> <rise> <width> <alpha>");
            System.out.println(" e.g.  java InteractiveStairsShape 5 1 0.2 2 0");
            System.exit(0);
        }
        int n = Integer.parseInt(args[0]);
        double tread = Double.parseDouble(args[1]);
        double rise  = Double.parseDouble(args[2]);
        double width = Double.parseDouble(args[3]);
        double alpha = Double.parseDouble(args[4]);

        new InteractiveStairsShape(n, tread, rise, width, alpha);
    }
}
