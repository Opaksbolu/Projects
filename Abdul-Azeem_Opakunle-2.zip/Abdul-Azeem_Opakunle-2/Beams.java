import java.io.*;

public class Beams {
    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.out.println("Usage: java Beams <steps> <a> <alpha> <output_file>");
            return;
        }

        int n = Integer.parseInt(args[0]);
        double a = Double.parseDouble(args[1]);
        double alpha = Math.toRadians(Double.parseDouble(args[2]));
        String filename = args[3];

        PrintWriter writer = new PrintWriter(new FileWriter(filename));
        double x = 0, y = 0, z = 0, angle = 0;

        for (int i = 0; i < n; i++) {
            double x1 = x + a * Math.cos(angle);
            double y1 = y + a * Math.sin(angle);
            double z1 = z + a;

            writer.printf("%.4f %.4f %.4f\n", x, y, z);
            writer.printf("%.4f %.4f %.4f\n", x1, y1, z);
            writer.printf("%.4f %.4f %.4f\n", x1, y1, z1);
            writer.printf("%.4f %.4f %.4f\n", x, y, z1);

            x = x1;
            y = y1;
            z = z1;
            angle += alpha;
        }

        writer.close();
        System.out.println("Step data written to " + filename);
    }
}
