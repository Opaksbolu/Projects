import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * MultiSegmentStairs
 *
 * Generates a multi-segment (L-shaped) staircase with a landing in between.
 * Then displays it in an interactive 3D viewer:
 *   - Click & drag to rotate the shape in real time.
 *   - Simple hidden-surface fill so it looks like a single 3D structure.
 *
 * By default, we show an example L-shape:
 *   - Segment1: n1 steps
 *   - A landing platform
 *   - Segment2: n2 steps rotated 90 degrees about the z-axis
 *
 * If your reference shape differs (e.g. one segment, or more segments, or curved),
 * you can adapt the code: see the "buildSegment()" method.
 */
public class MultiSegmentStairs extends JFrame {

    // ---------- Data Structures ----------
    static class Point3D { double x, y, z; Point3D(double x, double y, double z){this.x=x; this.y=y; this.z=z;} }
    static class Polygon3D { ArrayList<Point3D> verts = new ArrayList<>(); }
    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // ---------- 3D Rendering Settings ----------
    private double rotateXDeg = 0.0;  // updated by mouse
    private double rotateYDeg = 0.0;  // updated by mouse
    private double cameraDist = 80.0; // distance for perspective
    private double scale      = 6.0;  // enlarge shape
    private double shiftX=0, shiftY=0, shiftZ=0; // optional shift
    private Color fillColor = Color.LIGHT_GRAY;  // or any neutral color
    private int lastMouseX, lastMouseY;

    // ---------- Constructor ----------
    public MultiSegmentStairs() {
        super("Multi-Segment (L-Shaped) Staircase");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Example: Build an L-shaped set of stairs with a landing
        buildStaircaseExample();

        // Mouse drag -> rotates shape
        addMouseListener(new MouseAdapter(){
            @Override
            public void mousePressed(MouseEvent e){
                lastMouseX = e.getX();
                lastMouseY = e.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter(){
            @Override
            public void mouseDragged(MouseEvent e){
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;
                lastMouseX = e.getX();
                lastMouseY = e.getY();
                // rotate
                rotateYDeg += dx * 0.5;
                rotateXDeg += dy * 0.5;
                repaint();
            }
        });

        setVisible(true);
    }

    /**
     * buildStaircaseExample():
     *   As an example, we'll build:
     *   1) A first segment of 5 steps, each TREAD=1, RISE=0.2, WIDTH=2, alpha=0 (straight).
     *   2) A landing platform (like a big step with 2x the tread).
     *   3) A second segment of 5 steps, rotated 90 degrees about z from the first,
     *      so it forms an L-shape.
     *
     * If your reference shape is different, tweak these numbers or create more segments.
     */
    private void buildStaircaseExample() {
        // Segment1: 5 steps (straight)
        double n1 = 5;
        double tread1 = 1.0;
        double rise1  = 0.2;
        double width1 = 2.0;
        double alpha1 = 0.0; // no rotation step-to-step
        double offsetX = 0.0, offsetY = 0.0, offsetZ = 0.0; // starting at (0,0,0)

        // build the first run
        offsetZ = buildSegment(n1, tread1, rise1, width1, alpha1, offsetX, offsetY, offsetZ);

        // add a landing
        // let's make the landing 2 * tread deep, same width, same top height
        double landingTread = 2.0; // or bigger if you want
        offsetZ = addLanding(width1, landingTread, rise1, offsetX, offsetY, offsetZ);

        // Now the second run: let's do 5 steps, turning 90° about z
        double n2 = 5;
        double tread2 = 1.0;
        double rise2  = 0.2;
        double width2 = 2.0;
        // We'll rotate each step by alpha=0 relative to each other, but the entire segment
        // is turned 90° from the first. We'll do that by rotating the *local coords*:
        double segmentTurnDeg = 90.0;

        // build second run
        offsetZ = buildSegment(n2, tread2, rise2, width2, 0.0 /*alpha each step*/,
                               offsetX, offsetY, offsetZ, segmentTurnDeg /* entire run rotation*/);
    }

    /**
     * buildSegment():
     *   Builds a run of "n" steps, each sized (width, tread, rise).
     *   Optionally rotate each step by alpha after placing it. That creates a spiral if alpha != 0.
     *   Then returns the new offsetZ so you can keep stacking above.
     *
     * Overload 1: no segmentTurnDeg -> 0.0
     */
    private double buildSegment(double n, double tread, double rise, double width, double alphaDeg,
                                double offsetX, double offsetY, double offsetZ) {
        return buildSegment(n, tread, rise, width, alphaDeg, offsetX, offsetY, offsetZ, 0.0);
    }

    /**
     * Overload 2: includes a segment-level rotation "segmentTurnDeg"
     *   so the entire run is oriented differently (like turning 90°).
     *
     * Returns the updated offsetZ after building steps
     */
    private double buildSegment(double n, double tread, double rise, double width, double alphaDeg,
                                double baseOffsetX, double baseOffsetY, double baseOffsetZ,
                                double segmentTurnDeg)
    {
        double segRadians = Math.toRadians(segmentTurnDeg);

        // We'll keep track of the "current position" in local segment coords (0..n steps).
        // We'll transform each local corner by segRadians, then add the base offset in world coords.
        double currentAngleDeg = 0.0;
        double localX = 0.0, localY = 0.0, localZ = 0.0; // in segment coords

        for(int i=0; i<(int)n; i++){
            double stepRadians = Math.toRadians(currentAngleDeg);

            // build one rectangular block in local coords
            // X: 0..width, Y: 0..tread, Z: 0..rise
            double[][] c = {
                {0,     0,      0},
                {width, 0,      0},
                {width, tread,  0},
                {0,     tread,  0},
                {0,     0,      rise},
                {width, 0,      rise},
                {width, tread,  rise},
                {0,     tread,  rise}
            };

            // rotate about z by stepRadians, then rotate about z by segRadians
            // then add base offset, then add localX,localY,localZ
            for(int idx=0; idx<8; idx++){
                double xx = c[idx][0];
                double yy = c[idx][1];
                double zz = c[idx][2];

                // step rotation
                double sx = xx*Math.cos(stepRadians) - yy*Math.sin(stepRadians);
                double sy = xx*Math.sin(stepRadians) + yy*Math.cos(stepRadians);

                // now place in local coords
                sx += localX;
                sy += localY;
                double sz = zz + localZ;

                // segment-level rotation
                double fx = sx*Math.cos(segRadians) - sy*Math.sin(segRadians);
                double fy = sx*Math.sin(segRadians) + sy*Math.cos(segRadians);

                // now shift by base offsets
                fx += baseOffsetX;
                fy += baseOffsetY;
                double fz = sz + baseOffsetZ;

                c[idx][0] = fx;
                c[idx][1] = fy;
                c[idx][2] = fz;
            }

            // Add faces to polygons
            addQuad(c[0], c[1], c[2], c[3]); // bottom
            addQuad(c[4], c[5], c[6], c[7]); // top
            addQuad(c[0], c[1], c[5], c[4]); // front
            addQuad(c[3], c[2], c[6], c[7]); // back
            addQuad(c[1], c[2], c[6], c[5]); // right
            addQuad(c[0], c[3], c[7], c[4]); // left

            // move local coords forward by tread, up by rise
            currentAngleDeg += alphaDeg; // spiral step rotation
            double dxLocal = 0;
            double dyLocal = tread;
            double stepRad = Math.toRadians(currentAngleDeg - alphaDeg);
            double rx = dxLocal*Math.cos(stepRad) - dyLocal*Math.sin(stepRad);
            double ry = dxLocal*Math.sin(stepRad) + dyLocal*Math.cos(stepRad);
            localX += rx;
            localY += ry;
            localZ += rise;
        }

        // final top of last step = baseOffsetZ + localZ
        return baseOffsetZ + localZ;
    }

    /**
     * addLanding():
     *   Adds one big rectangular block of (width x landingTread x rise) as a "landing."
     *   You can customize to be bigger or flush with the last step, etc.
     *   Returns the new offsetZ after adding it.
     */
    private double addLanding(double width, double landingTread, double rise,
                              double baseOffsetX, double baseOffsetY, double baseOffsetZ)
    {
        // We'll put the landing at the same orientation as the first run (no seg turn),
        // at current baseOffset. If you want a different orientation, you can rotate similarly.
        // corners:
        double[][] c = {
            {0,      0,       0},
            {width,  0,       0},
            {width,  landingTread, 0},
            {0,      landingTread, 0},
            {0,      0,       rise},
            {width,  0,       rise},
            {width,  landingTread, rise},
            {0,      landingTread, rise}
        };
        // shift by baseOffset
        for(int i=0; i<8; i++){
            c[i][0] += baseOffsetX;
            c[i][1] += baseOffsetY;
            c[i][2] += baseOffsetZ;
        }
        // add faces
        addQuad(c[0], c[1], c[2], c[3]); // bottom
        addQuad(c[4], c[5], c[6], c[7]); // top
        addQuad(c[0], c[1], c[5], c[4]); // front
        addQuad(c[3], c[2], c[6], c[7]); // back
        addQuad(c[1], c[2], c[6], c[5]); // right
        addQuad(c[0], c[3], c[7], c[4]); // left

        return baseOffsetZ + rise; // now the "top" is one "rise" higher
    }

    // Helper: add a quad face to polygons
    private void addQuad(double[] v1, double[] v2, double[] v3, double[] v4){
        Polygon3D poly = new Polygon3D();
        poly.verts.add(new Point3D(v1[0], v1[1], v1[2]));
        poly.verts.add(new Point3D(v2[0], v2[1], v2[2]));
        poly.verts.add(new Point3D(v3[0], v3[1], v3[2]));
        poly.verts.add(new Point3D(v4[0], v4[1], v4[2]));
        polygons.add(poly);
    }

    // ---------- Painting (Hidden-Surface via Z-Sort) ----------
    @Override
    public void paint(Graphics g){
        super.paint(g);
        int w = getWidth(), h = getHeight();

        // z-sort
        class PolyZ {
            Polygon3D poly; double zavg;
            PolyZ(Polygon3D p, double z){ poly=p; zavg=z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();
        for(Polygon3D poly : polygons){
            double sumZ=0; 
            for(Point3D pt : poly.verts){
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }
        // sort descending
        sorted.sort((a,b)->Double.compare(b.zavg, a.zavg));

        Graphics2D g2 = (Graphics2D)g;
        for(PolyZ pz : sorted){
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D p3 = transform(poly.verts.get(i));
                Point p2 = project(p3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            // fill + outline
            g2.setColor(fillColor);
            g2.fillPolygon(xp, yp, n);
            g2.setColor(Color.black);
            g2.drawPolygon(xp, yp, n);
        }
    }

    // transform: rotate about X & Y, then scale, ignoring shift
    private Point3D transform(Point3D p){
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;
        // rotate X
        double rx = Math.toRadians(rotateXDeg);
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double y1 = cx*y0 - sx*z0;
        double z1 = sx*y0 + cx*z0;
        double x1 = x0;
        // rotate Y
        double ry = Math.toRadians(rotateYDeg);
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double z2 = cy*z1 - sy*x1;
        double x2 = sy*z1 + cy*x1;
        double y2 = y1;
        // scale
        x2 *= scale; y2 *= scale; z2 *= scale;
        return new Point3D(x2,y2,z2);
    }

    // perspective projection
    private Point project(Point3D p, int width, int height){
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0; 
        return new Point((int)Math.round(sx),(int)Math.round(sy));
    }

    // ---------- main ----------
    public static void main(String[] args){
        new MultiSegmentStairs(); 
    }
}
