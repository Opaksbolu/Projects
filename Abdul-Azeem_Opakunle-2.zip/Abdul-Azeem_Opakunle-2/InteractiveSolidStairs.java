import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * InteractiveSolidStairs
 *
 * Generates ascending stairs in 3D (straight or spiral),
 * then shows a colored, filled 3D rendering with basic hidden-surface
 * (z-sorting). You can click and drag to rotate in real time.
 *
 * Usage:
 *   java InteractiveSolidStairs <n> <tread> <rise> <width> <alpha>
 *
 * Example:
 *   java InteractiveSolidStairs 5 1 0.2 2 0
 *   -> 5 connected straight steps, each 1 deep, 0.2 tall, 2 wide.
 *
 *   java InteractiveSolidStairs 10 1 0.2 1.5 15
 *   -> 10 spiral steps, each turned 15°, narrower width, 1 deep, 0.2 tall.
 *
 * Tweak the geometry arguments to match the "tidy" shape you want,
 * and you can also adjust the fillColor below to any color you like.
 */
public class InteractiveSolidStairs extends JFrame {

    // ------------------- Data Structures --------------------

    // A simple 3D point
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z){
            this.x = x; this.y = y; this.z = z;
        }
    }

    // A polygon (face) with a list of 3D corners
    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }

    // The set of all faces (polygons) for the entire staircase
    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // ------------------- Rendering Parameters --------------------

    // We’ll do a simple perspective projection and allow mouse rotation:
    private double rotateXDeg = 0.0;  // updated by dragging vertically
    private double rotateYDeg = 0.0;  // updated by dragging horizontally
    private double cameraDist = 60.0; // move camera further away if shape is large
    private double scale = 6.0;       // enlarge the shape so it fills the window
    private double shiftX = 0.0, shiftY = 0.0, shiftZ = 0.0; // optional shifts

    // We’ll fill all faces with a single color (like your “yellow” example).
    private Color fillColor = new Color(226, 202, 0); // a golden yellow

    // Track mouse drag
    private int lastMouseX, lastMouseY;

    // ------------------- Constructor --------------------
    public InteractiveSolidStairs(int n, double tread, double rise, double width, double alphaDeg) {
        super("Interactive Solid Stairs: n="+n+" tread="+tread+" rise="+rise+" width="+width+" alpha="+alphaDeg);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Build the 3D staircase polygons:
        generateStairs(n, tread, rise, width, alphaDeg);

        // Add mouse listeners for dragging to rotate
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastMouseX = e.getX();
                lastMouseY = e.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;
                lastMouseX = e.getX();
                lastMouseY = e.getY();

                rotateYDeg += dx * 0.5; // horizontal drag → rotate Y
                rotateXDeg += dy * 0.5; // vertical drag → rotate X
                repaint();
            }
        });

        setVisible(true);
    }

    // ------------------- Stair Generation --------------------
    /**
     * generateStairs:
     *  Creates "n" rectangular blocks, each sized (width, tread, rise).
     *  After placing each step, we rotate about Z by alphaDeg, then move
     *  forward by tread and up by rise, so steps ascend. If alpha=0 => straight.
     *
     *  Polygons are stored in 'polygons' for later rendering.
     */
    private void generateStairs(int n, double tread, double rise, double width, double alphaDeg) {
        double currentAngleDeg = 0.0;
        double offsetX = 0.0, offsetY = 0.0, offsetZ = 0.0;

        // If you want to space out spiral more, increase "spiralFactor".
        double spiralFactor = (alphaDeg == 0.0 ? 1.0 : 1.0); 
        // (Set to e.g. 1.3 if you want more separation for spiral)

        for(int i=0; i<n; i++){
            double radians = Math.toRadians(currentAngleDeg);

            // corners of one rectangular step in local coords
            // X from 0..width, Y from 0..tread, Z from 0..rise
            double[][] c = {
                {0,     0,      0},
                {width, 0,      0},
                {width, tread,  0},
                {0,     tread,  0},
                {0,     0,      rise},
                {width, 0,      rise},
                {width, tread,  rise},
                {0,     tread,  rise}
            };

            // Rotate about Z, then offset in world
            for(int idx=0; idx<8; idx++){
                double xx = c[idx][0];
                double yy = c[idx][1];
                double zz = c[idx][2];

                double xRot = xx*Math.cos(radians) - yy*Math.sin(radians);
                double yRot = xx*Math.sin(radians) + yy*Math.cos(radians);

                c[idx][0] = xRot + offsetX;
                c[idx][1] = yRot + offsetY;
                c[idx][2] = zz    + offsetZ;
            }

            // Add the 6 faces
            addQuad(c[0], c[1], c[2], c[3]); // bottom
            addQuad(c[4], c[5], c[6], c[7]); // top
            addQuad(c[0], c[1], c[5], c[4]); // front
            addQuad(c[3], c[2], c[6], c[7]); // back
            addQuad(c[1], c[2], c[6], c[5]); // right
            addQuad(c[0], c[3], c[7], c[4]); // left

            // Move to next step
            currentAngleDeg += alphaDeg;
            double dxLocal = 0.0;
            double dyLocal = tread * spiralFactor;
            double dxWorld = dxLocal*Math.cos(radians) - dyLocal*Math.sin(radians);
            double dyWorld = dxLocal*Math.sin(radians) + dyLocal*Math.cos(radians);

            offsetX += dxWorld;
            offsetY += dyWorld;
            offsetZ += rise;
        }
    }

    // Helper: add one quadrilateral face to 'polygons'
    private void addQuad(double[] v1, double[] v2, double[] v3, double[] v4) {
        Polygon3D poly = new Polygon3D();
        poly.verts.add(new Point3D(v1[0], v1[1], v1[2]));
        poly.verts.add(new Point3D(v2[0], v2[1], v2[2]));
        poly.verts.add(new Point3D(v3[0], v3[1], v3[2]));
        poly.verts.add(new Point3D(v4[0], v4[1], v4[2]));
        polygons.add(poly);
    }

    // ------------------- Painting (Fill Polygons) --------------------
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth(), h = getHeight();

        // We do a naive z-sort of polygons by average depth
        class PolyZ {
            Polygon3D poly;
            double zavg;
            PolyZ(Polygon3D p, double z){ poly=p; zavg=z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();
        for(Polygon3D poly : polygons){
            double sumZ=0;
            for(Point3D pt : poly.verts){
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }
        // sort descending so we draw farthest first
        sorted.sort((a,b)->Double.compare(b.zavg, a.zavg));

        // Now fill each polygon
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(fillColor); // single fill color for all steps

        for(PolyZ pz : sorted){
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D r3 = transform(poly.verts.get(i));
                Point p2 = project(r3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            // fill the face
            g2.fillPolygon(xp, yp, n);
            // optional: draw edges in black
            g2.setColor(Color.black);
            g2.drawPolygon(xp, yp, n);
            g2.setColor(fillColor); // restore fill color for next face
        }
    }

    // transform: apply rotation about X & Y, then scale. (No shading.)
    private Point3D transform(Point3D p) {
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        // rotate about X
        double rx = Math.toRadians(rotateXDeg);
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double y1 = cx*y0 - sx*z0;
        double z1 = sx*y0 + cx*z0;
        double x1 = x0;

        // rotate about Y
        double ry = Math.toRadians(rotateYDeg);
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double z2 = cy*z1 - sy*x1;
        double x2 = sy*z1 + cy*x1;
        double y2 = y1;

        // scale
        x2 *= scale; 
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    // perspective projection
    private Point project(Point3D p, int width, int height){
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0;
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    // ------------------- MAIN --------------------
    public static void main(String[] args) {
        if(args.length < 5){
            System.out.println("Usage: java InteractiveSolidStairs <n> <tread> <rise> <width> <alpha>");
            System.out.println(" e.g. java InteractiveSolidStairs 5 1 0.2 2 0");
            System.exit(0);
        }
        int n = Integer.parseInt(args[0]);
        double tread = Double.parseDouble(args[1]);
        double rise  = Double.parseDouble(args[2]);
        double width = Double.parseDouble(args[3]);
        double alpha = Double.parseDouble(args[4]);

        new InteractiveSolidStairs(n, tread, rise, width, alpha);
    }
}
