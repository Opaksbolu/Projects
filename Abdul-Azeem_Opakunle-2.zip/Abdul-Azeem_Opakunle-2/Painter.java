import java.io.*;
import java.util.*;

public class Painter {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Usage: java Painter <stepsX.dat>");
            return;
        }

        try (Scanner sc = new Scanner(new File(args[0]))) {
            List<double[]> vertices = new ArrayList<>();

            while (sc.hasNextDouble()) {
                double[] v = new double[3];
                v[0] = sc.nextDouble();
                v[1] = sc.nextDouble();
                v[2] = sc.nextDouble();
                vertices.add(v);
            }

            System.out.println("Rendering Steps Structure:");
            for (int i = 0; i < vertices.size(); i += 4) {
                System.out.printf("Step %d:%n", (i / 4) + 1);
                for (int j = 0; j < 4; j++) {
                    double[] v = vertices.get(i + j);
                    System.out.printf("  Vertex %d: (%.2f, %.2f, %.2f)%n", j + 1, v[0], v[1], v[2]);
                }
            }
        }
    }
}
