import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class HLines extends JFrame {
    // ---------- Data Structures ----------
    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z){
            this.x = x; 
            this.y = y; 
            this.z = z;
        }
    }

    private ArrayList<Polygon3D> polygons;

    // ---------- Transform/Viewing Settings ----------
    // Try these angles & scale to match your reference diagram.
    private double rotateXDeg = 25.0; 
    private double rotateYDeg = -35.0;
    private double rotateZDeg = 0.0;   // If needed, tweak further

    private double shiftX  = -5.0;     // Because your cube is 0..10 in each axis
    private double shiftY  = -5.0;     // shifting by -5 moves center to origin
    private double shiftZ  = -5.0;

    private double scale   = 30.0;     // Enlarge so it fills the window
    private double cameraDist = 250.0; // Distance for perspective

    public HLines(String filename) {
        super("HLines: Cube + Pyramid, Updated View");
        polygons = new ArrayList<>();
        readPolygons(filename);

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // ---------- 1) Read the polygon data file ----------
    private void readPolygons(String filename){
        try(BufferedReader br = new BufferedReader(new FileReader(filename))){
            int numPolys = Integer.parseInt(br.readLine().trim());
            for(int i=0; i<numPolys; i++){
                String line = br.readLine().trim();
                String[] tokens = line.split("\\s+");
                int nVerts = Integer.parseInt(tokens[0]);
                Polygon3D poly = new Polygon3D();
                int idx = 1;
                for(int v=0; v<nVerts; v++){
                    double x = Double.parseDouble(tokens[idx++]);
                    double y = Double.parseDouble(tokens[idx++]);
                    double z = Double.parseDouble(tokens[idx++]);
                    poly.verts.add(new Point3D(x,y,z));
                }
                polygons.add(poly);
            }
        } catch(Exception e){
            e.printStackTrace();
            System.exit(1);
        }
    }

    // ---------- 2) Transform a 3D point (shift, rotate, scale) ----------
    private Point3D transform(Point3D p){
        // Shift so center is near (0,0,0)
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        // Rotate about X
        double rx = Math.toRadians(rotateXDeg);
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double y1 =  cx*y0 - sx*z0;
        double z1 =  sx*y0 + cx*z0;
        double x1 =  x0;

        // Rotate about Y
        double ry = Math.toRadians(rotateYDeg);
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double z2 =  cy*z1 - sy*x1;
        double x2 =  sy*z1 + cy*x1;
        double y2 =  y1;

        // Rotate about Z (optional)
        double rz = Math.toRadians(rotateZDeg);
        double cz = Math.cos(rz), sz = Math.sin(rz);
        double x3 = x2*cz - y2*sz;
        double y3 = x2*sz + y2*cz;
        double z3 = z2;

        // Scale
        x3 *= scale;
        y3 *= scale;
        z3 *= scale;

        return new Point3D(x3,y3,z3);
    }

    // ---------- 3) Perspective projection ----------
    private Point project(Point3D p, int width, int height){
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor + width/2.0;
        double py = -p.y * factor + height/2.0; // invert Y
        return new Point((int)Math.round(px), (int)Math.round(py));
    }

    // ---------- 4) Paint with naive hidden-line via z-sort ----------
    @Override
    public void paint(Graphics g){
        super.paint(g);
        class PolyZ {
            Polygon3D poly;
            double zavg;
            PolyZ(Polygon3D p, double z){ poly=p; zavg=z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();

        // For each polygon, get average Z (post-transform)
        for(Polygon3D poly : polygons){
            double sumZ=0;
            for(Point3D pt : poly.verts){
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }
        // Sort descending so the farthest polygons are drawn first
        sorted.sort((a,b)->Double.compare(b.zavg, a.zavg));

        int w = getWidth(), h = getHeight();
        // Now draw in that order
        for(PolyZ pz : sorted){
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D r3 = transform(poly.verts.get(i));
                Point p2 = project(r3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            // Draw polygon wireframe
            g.drawPolygon(xp, yp, n);
        }
    }

    // ---------- main ----------
    public static void main(String[] args){
        if(args.length < 1){
            System.out.println("Usage: java HLines <objectDataFile>");
            System.exit(0);
        }
        new HLines(args[0]);
    }
}
