import java.awt.*;
import java.awt.event.*; // keep it
import javax.swing.*;
import java.io.*;
import java.util.*;

public class CubePers extends JFrame {
    private StringBuilder debugLog = new StringBuilder();

    // Use KeyEvent so we "really" use the event import
    private KeyEvent exampleKeyEvent;

    private ArrayList<Point3D> vertices;
    private ArrayList<int[]> edges; 

    private double eyeZ = 200.0;  // distance for perspective
    private double scale = 3.0;   // scale factor to make the cube bigger on screen

    public static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z){
            this.x = x; 
            this.y = y; 
            this.z = z;
        }
    }

    public CubePers(String filename){
        super("Cube in Perspective");
        vertices = new ArrayList<>();
        edges = new ArrayList<>();
        readData(filename);

        // Use event code
        exampleKeyEvent = new KeyEvent(
            new TextField(), 
            KeyEvent.KEY_RELEASED, 
            System.currentTimeMillis(), 
            0, 
            KeyEvent.VK_C, 
            'c'
        );
        debugLog.append("CubePers: exampleKeyEvent code=" + exampleKeyEvent.getKeyCode() + "\n");

        // Window adapter
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e){
                debugLog.append("CubePers window closing.\n");
                System.out.println(debugLog.toString());
                System.exit(0);
            }
        });

        setSize(600,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        debugLog.append("CubePers initialized with " + vertices.size() 
                        + " vertices and " + edges.size() + " edges.\n");
    }

    private void readData(String filename){
        try(BufferedReader br = new BufferedReader(new FileReader(filename))){
            int nVerts = Integer.parseInt(br.readLine().trim());
            debugLog.append("Reading " + nVerts + " vertices.\n");
            for(int i=0; i<nVerts; i++){
                String line = br.readLine().trim();
                String[] toks = line.split("\\s+");
                double x = Double.parseDouble(toks[0]);
                double y = Double.parseDouble(toks[1]);
                double z = Double.parseDouble(toks[2]);
                vertices.add(new Point3D(x,y,z));
            }
            int nEdges = Integer.parseInt(br.readLine().trim());
            debugLog.append("Reading " + nEdges + " edges.\n");
            for(int e=0; e<nEdges; e++){
                String line = br.readLine().trim();
                String[] toks = line.split("\\s+");
                int v1 = Integer.parseInt(toks[0]);
                int v2 = Integer.parseInt(toks[1]);
                edges.add(new int[]{v1, v2});
            }
        } catch(IOException e){
            e.printStackTrace();
        }
    }

    // perspective projection
    private Point project(Point3D p, int width, int height){
        // Scale coordinates to enlarge
        double sx = p.x * scale;
        double sy = p.y * scale;
        double sz = p.z * scale;

        double zFactor = eyeZ / (eyeZ - sz);
        double px = sx * zFactor + width/2.0;
        double py = -sy * zFactor + height/2.0;
        return new Point((int)px, (int)py);
    }

    public void paint(Graphics g){
        super.paint(g);
        int w = getWidth();
        int h = getHeight();
        for(int[] e : edges){
            Point3D p1 = vertices.get(e[0]);
            Point3D p2 = vertices.get(e[1]);
            Point pt1 = project(p1, w, h);
            Point pt2 = project(p2, w, h);
            g.drawLine(pt1.x, pt1.y, pt2.x, pt2.y);
        }
    }

    public static void main(String[] args){
        if(args.length < 1){
            System.out.println("Usage: java CubePers <cubeDataFile>");
            return;
        }
        new CubePers(args[0]);
    }
}
