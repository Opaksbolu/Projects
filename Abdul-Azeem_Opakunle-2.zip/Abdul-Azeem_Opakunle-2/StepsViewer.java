import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * StepsViewer generates a set of "steps" (blocks) in 3D, then displays
 * them immediately in a new window with a simple perspective wireframe.
 *
 * Usage:
 *   java StepsViewer <n> <a> <alpha>
 *
 *   - n = number of steps
 *   - a = size (length/width) of each step
 *   - alpha = rotation in degrees between steps (0 for straight stairs)
 *
 * Example:
 *   java StepsViewer 5 2 0
 *   -> 5 straight steps, each size=2
 *
 *   java StepsViewer 5 2 30
 *   -> 5 steps, each size=2, with a 30-degree spiral
 */
public class StepsViewer extends JFrame {

    // A simple 3D point type
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z) {
            this.x = x; this.y = y; this.z = z;
        }
    }

    // A polygon with multiple 3D vertices
    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }

    // We'll store all generated polygons here
    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // --- Rendering parameters (adjust as you like) ---
    private double rotateXDeg = 20.0;  // tilt the shape around X
    private double rotateYDeg = 20.0;  // tilt the shape around Y
    private double scale       = 5.0;  // make shape bigger on screen
    private double cameraDist  = 50.0; // distance for perspective

    // We'll shift the shape so (0,0,0) doesn't sit in the corner of the window
    private double shiftX = 0.0;
    private double shiftY = 0.0;
    private double shiftZ = 0.0; // feel free to adjust if blocks vanish behind camera

    public StepsViewer(int n, double a, double alphaDeg) {
        super("Steps Viewer: n="+n+", a="+a+", alpha="+alphaDeg);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Generate the polygons in memory
        generateSteps(n, a, alphaDeg);

        setVisible(true);
    }

    /**
     * generateSteps:
     * Creates n rectangular blocks, each of dimension 'a',
     * stacked (and optionally rotated) in 3D. Stores polygons in 'polygons'.
     */
    private void generateSteps(int n, double a, double alphaDeg) {
        double currentAngle = 0.0;
        double xOffset = 0.0, yOffset = 0.0;
        double stepHeight = 0.0; // each block is at a different z-level if we want

        for(int i=0; i<n; i++){
            double radians = Math.toRadians(currentAngle);

            // corners of one rectangular block (8 corners)
            // block extends from (0,0,0) to (a,a,1) in local coords
            double[][] c = {
                {0,  0,  0},  {a,  0,  0},  {a,  a,  0},  {0,  a,  0},
                {0,  0,  1},  {a,  0,  1},  {a,  a,  1},  {0,  a,  1}
            };

            // rotate each corner about Z, then translate
            for(int idx=0; idx<8; idx++){
                double xx = c[idx][0];
                double yy = c[idx][1];
                double zz = c[idx][2];

                // rotate about Z by currentAngle
                double xRot = xx * Math.cos(radians) - yy * Math.sin(radians);
                double yRot = xx * Math.sin(radians) + yy * Math.cos(radians);

                // add offset in XY, stepHeight in Z
                c[idx][0] = xRot + xOffset;
                c[idx][1] = yRot + yOffset;
                c[idx][2] = zz + stepHeight;
            }

            // Now create 6 faces (each face = 4 vertices)
            addQuad(c[0], c[1], c[2], c[3]); // bottom
            addQuad(c[4], c[5], c[6], c[7]); // top
            addQuad(c[0], c[1], c[5], c[4]); // front
            addQuad(c[3], c[2], c[6], c[7]); // back
            addQuad(c[1], c[2], c[6], c[5]); // right
            addQuad(c[0], c[3], c[7], c[4]); // left

            // update offsets so next step is placed at the end of this step
            xOffset += a * Math.cos(radians);
            yOffset += a * Math.sin(radians);

            // we can increment stepHeight if we want them to go "up" each time
            stepHeight += 1.0;

            // increment rotation angle for spiral
            currentAngle += alphaDeg;
        }
    }

    // Helper to add a 4-vertex polygon to 'polygons'
    private void addQuad(double[] v1, double[] v2, double[] v3, double[] v4){
        Polygon3D poly = new Polygon3D();
        poly.verts.add(new Point3D(v1[0], v1[1], v1[2]));
        poly.verts.add(new Point3D(v2[0], v2[1], v2[2]));
        poly.verts.add(new Point3D(v3[0], v3[1], v3[2]));
        poly.verts.add(new Point3D(v4[0], v4[1], v4[2]));
        polygons.add(poly);
    }

    /**
     * paint: called by Swing to draw the window
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth();
        int h = getHeight();

        // We'll do a naive "z-sort" by average polygon depth so it looks a bit better
        // This is not perfect hidden-surface, but better than random.
        class PolyZ {
            Polygon3D poly;
            double zavg;
            PolyZ(Polygon3D p, double z) { poly = p; zavg = z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();

        // compute average depth for each polygon
        for(Polygon3D poly : polygons){
            double sumZ = 0;
            for(Point3D pt : poly.verts){
                // We'll transform (rotate in 3D) then see how far it is
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }

        // sort descending so farthest is drawn first
        sorted.sort((a,b) -> Double.compare(b.zavg, a.zavg));

        // draw them
        for(PolyZ pz : sorted) {
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D tpt = transform(poly.verts.get(i));
                Point p2 = project(tpt, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            g.drawPolygon(xp, yp, n);
        }
    }

    // Apply rotation about X, Y, shift, scale, etc.
    private Point3D transform(Point3D p) {
        // shift
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        // rotate X
        double rx = Math.toRadians(rotateXDeg);
        double cX = Math.cos(rx), sX = Math.sin(rx);
        double y1 =  cX*y0 - sX*z0;
        double z1 =  sX*y0 + cX*z0;
        double x1 =  x0;

        // rotate Y
        double ry = Math.toRadians(rotateYDeg);
        double cY = Math.cos(ry), sY = Math.sin(ry);
        double z2 =  cY*z1 - sY*x1;
        double x2 =  sY*z1 + cY*x1;
        double y2 =  y1;

        // scale
        x2 *= scale;
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    // perspective projection
    private Point project(Point3D p, int width, int height) {
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;

        double sx = px + width / 2.0;
        double sy = -py + height / 2.0; // invert Y
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    // --- main method: reads command-line args, opens the window ---
    public static void main(String[] args) {
        if(args.length < 3) {
            System.out.println("Usage: java StepsViewer <n> <a> <alpha>");
            System.out.println("Example: java StepsViewer 5 2 0    (straight steps)");
            System.out.println("         java StepsViewer 5 2 30   (spiral steps)");
            return;
        }
        int n = Integer.parseInt(args[0]);
        double a = Double.parseDouble(args[1]);
        double alpha = Double.parseDouble(args[2]);

        new StepsViewer(n, a, alpha);
    }
}
