import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * InteractiveStairsViewer
 *
 * Generates ascending stairs, either straight (alpha=0) or spiral (alpha>0),
 * then opens an interactive 3D window where you can drag with the mouse
 * to rotate the shape from any angle.
 *
 * This version:
 *  - Ensures STRAIGHT stairs remain fully connected with no gaps
 *  - Spaces out SPIRAL stairs more to match the user's request
 *
 * Usage:
 *   java InteractiveStairsViewer <n> <tread> <rise> <width> <alpha>
 *
 * Example:
 *   java InteractiveStairsViewer 10 1 0.2 2 0
 *   -> 10 fully connected straight steps
 *
 *   java InteractiveStairsViewer 10 1 0.2 2 15
 *   -> 10 steps, rotating 15° each, spaced out for a spiral
 */
public class InteractiveStairsViewer extends JFrame {

    // A simple 3D point type
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z) {
            this.x = x; 
            this.y = y; 
            this.z = z;
        }
    }

    // A polygon with multiple 3D vertices
    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }

    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // Camera / transform settings
    private double rotateXDeg = 0.0;  // updated by mouse drag
    private double rotateYDeg = 0.0;  // updated by mouse drag
    private double cameraDist = 50.0; // distance for perspective
    private double scale      = 5.0;  // enlarge shape on screen
    private double shiftX=0, shiftY=0, shiftZ=0; // if needed

    // Mouse drag state
    private int lastMouseX, lastMouseY;

    public InteractiveStairsViewer(int n, double tread, double rise, double width, double alphaDeg) {
        super("Interactive Stairs: n="+n+" tread="+tread+" rise="+rise+" width="+width+" alpha="+alphaDeg);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Generate the 3D polygons for the requested stairs
        generateStairs(n, tread, rise, width, alphaDeg);

        // Mouse listeners to let you rotate the scene by dragging
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastMouseX = e.getX();
                lastMouseY = e.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;
                lastMouseX = e.getX();
                lastMouseY = e.getY();

                rotateYDeg += dx * 0.5;  // horizontal drag → rotate Y
                rotateXDeg += dy * 0.5;  // vertical drag → rotate X
                repaint();
            }
        });

        setVisible(true);
    }

    /**
     * generateStairs:
     *  Creates n rectangular "step blocks" each sized:
     *     (width in X) x (tread in Y) x (rise in Z)
     *  Then positions them so they ascend in Z, moving forward in Y,
     *  and optionally rotating each step about Z-axis by alphaDeg
     *  (spiral if alphaDeg != 0, straight if alphaDeg=0).
     *
     *  For spiral, we apply an extra factor to "space out" the steps more.
     */
    private void generateStairs(int n, double tread, double rise, double width, double alphaDeg) {
        double currentAngleDeg = 0.0;
        double offsetX = 0.0, offsetY = 0.0, offsetZ = 0.0;

        // We'll define a factor for spiral spacing:
        // If alpha=0 (straight), factor=1 (so no gap).
        // If alpha!=0 (spiral), factor>1 for extra spacing
        double spacingFactor = (alphaDeg == 0.0) ? 1.0 : 1.5;

        for(int i=0; i<n; i++){
            double radians = Math.toRadians(currentAngleDeg);

            // corners of a single step block in local coords
            //   X dimension: 0..width
            //   Y dimension: 0..tread
            //   Z dimension: 0..rise
            double[][] c = {
                {0,     0,      0},
                {width, 0,      0},
                {width, tread,  0},
                {0,     tread,  0},
                {0,     0,      rise},
                {width, 0,      rise},
                {width, tread,  rise},
                {0,     tread,  rise}
            };

            // Rotate each corner about Z, then add the offsets
            for(int idx=0; idx<8; idx++){
                double xx = c[idx][0];
                double yy = c[idx][1];
                double zz = c[idx][2];

                double xRot = xx * Math.cos(radians) - yy * Math.sin(radians);
                double yRot = xx * Math.sin(radians) + yy * Math.cos(radians);

                c[idx][0] = xRot + offsetX;
                c[idx][1] = yRot + offsetY;
                c[idx][2] = zz    + offsetZ;
            }

            // 6 faces of the block
            addQuad(c[0], c[1], c[2], c[3]); // bottom
            addQuad(c[4], c[5], c[6], c[7]); // top
            addQuad(c[0], c[1], c[5], c[4]); // front
            addQuad(c[3], c[2], c[6], c[7]); // back
            addQuad(c[1], c[2], c[6], c[5]); // right
            addQuad(c[0], c[3], c[7], c[4]); // left

            // Update offsets for the next step
            // We'll move forward in "y" by (tread * spacingFactor)
            // and upward by "rise", after rotating by 'radians' if spiral
            double dxLocal = 0.0;
            double dyLocal = tread * spacingFactor;

            double dxWorld = dxLocal*Math.cos(radians) - dyLocal*Math.sin(radians);
            double dyWorld = dxLocal*Math.sin(radians) + dyLocal*Math.cos(radians);

            offsetX += dxWorld;
            offsetY += dyWorld;
            offsetZ += rise;

            currentAngleDeg += alphaDeg;
        }
    }

    // Helper: add a quad (4 corners) to the polygons list
    private void addQuad(double[] v1, double[] v2, double[] v3, double[] v4) {
        Polygon3D poly = new Polygon3D();
        poly.verts.add(new Point3D(v1[0], v1[1], v1[2]));
        poly.verts.add(new Point3D(v2[0], v2[1], v2[2]));
        poly.verts.add(new Point3D(v3[0], v3[1], v3[2]));
        poly.verts.add(new Point3D(v4[0], v4[1], v4[2]));
        polygons.add(poly);
    }

    // =================== 3D Drawing =====================

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth(), h = getHeight();

        // We'll do a naive "z-sort" by avg depth
        class PolyZ {
            Polygon3D poly;
            double zavg;
            PolyZ(Polygon3D p, double z) { poly = p; zavg = z; }
        }
        ArrayList<PolyZ> sorted = new ArrayList<>();

        for(Polygon3D poly : polygons){
            double sumZ=0;
            for(Point3D pt : poly.verts){
                Point3D tpt = transform(pt);
                sumZ += tpt.z;
            }
            double avgZ = sumZ / poly.verts.size();
            sorted.add(new PolyZ(poly, avgZ));
        }

        // sort descending
        sorted.sort((a,b)->Double.compare(b.zavg, a.zavg));

        // draw them
        for(PolyZ pz : sorted){
            Polygon3D poly = pz.poly;
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D r3 = transform(poly.verts.get(i));
                Point p2 = project(r3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            g.drawPolygon(xp, yp, n);
        }
    }

    // transform: apply global rotation about X, Y, then scale, etc.
    private Point3D transform(Point3D p) {
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        // rotate about X
        double rx = Math.toRadians(rotateXDeg);
        double cX = Math.cos(rx), sX = Math.sin(rx);
        double y1 = cX*y0 - sX*z0;
        double z1 = sX*y0 + cX*z0;
        double x1 = x0;

        // rotate about Y
        double ry = Math.toRadians(rotateYDeg);
        double cY = Math.cos(ry), sY = Math.sin(ry);
        double z2 = cY*z1 - sY*x1;
        double x2 = sY*z1 + cY*x1;
        double y2 = y1;

        // scale
        x2 *= scale;
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    // perspective projection
    private Point project(Point3D p, int width, int height) {
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0;  // invert Y
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    // =================== MAIN =====================
    public static void main(String[] args) {
        if(args.length < 5) {
            System.out.println("Usage: java InteractiveStairsViewer <n> <tread> <rise> <width> <alpha>");
            System.out.println(" e.g.: java InteractiveStairsViewer 10 1 0.2 2 0   (straight, connected)");
            System.out.println("       java InteractiveStairsViewer 10 1 0.2 2 15  (spiral, spaced out)");
            System.exit(0);
        }
        int n = Integer.parseInt(args[0]);
        double tread = Double.parseDouble(args[1]);
        double rise  = Double.parseDouble(args[2]);
        double width = Double.parseDouble(args[3]);
        double alpha = Double.parseDouble(args[4]);

        new InteractiveStairsViewer(n, tread, rise, width, alpha);
    }
}
