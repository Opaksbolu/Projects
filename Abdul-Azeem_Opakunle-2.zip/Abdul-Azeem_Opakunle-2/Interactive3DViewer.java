import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class Interactive3DViewer extends JFrame {
    private StringBuilder logBuilder = new StringBuilder();

    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z) {
            this.x = x; 
            this.y = y; 
            this.z = z;
        }
    }

    private ArrayList<Polygon3D> polygons = new ArrayList<>();

    // Track rotation angles (in degrees)
    private double rotateXDeg = 0.0;
    private double rotateYDeg = 0.0;

    private double cameraDist = 50.0;
    private double scale = 5.0;

    private double shiftX = -5.0, shiftY = -5.0, shiftZ = -5.0;

    // Mouse drag
    private int lastMouseX, lastMouseY;

    public Interactive3DViewer(String filename) {
        super("Interactive 3D Viewer");
        readPolygons(filename);

        // minimal KeyEvent usage
        KeyEvent dummyKey = new KeyEvent(
            new Label("dummy"), 
            KeyEvent.KEY_PRESSED, 
            System.currentTimeMillis(), 
            0, 
            KeyEvent.VK_LEFT, 
            ' '
        );
        logBuilder.append("Created a dummy KeyEvent with code="+dummyKey.getKeyCode()+"\n");

        // mouse listener for rotation
        MouseAdapter ma = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastMouseX = e.getX();
                lastMouseY = e.getY();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;
                lastMouseX = e.getX();
                lastMouseY = e.getY();

                // Adjust angles based on mouse movement
                rotateYDeg += dx * 0.5; // horizontal drag → rotate Y
                rotateXDeg += dy * 0.5; // vertical drag → rotate X
                repaint();
            }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                logBuilder.append("Interactive3DViewer closing.\n");
                System.out.println(logBuilder.toString());
                System.exit(0);
            }
        });

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        logBuilder.append("Interactive3DViewer loaded file: " + filename + "\n");
    }

    private void readPolygons(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            int numPolys = Integer.parseInt(br.readLine().trim());
            for(int i=0; i<numPolys; i++){
                String line = br.readLine().trim();
                String[] tokens = line.split("\\s+");
                int nVerts = Integer.parseInt(tokens[0]);
                Polygon3D poly = new Polygon3D();
                int idx = 1;
                for(int v=0; v<nVerts; v++){
                    double x = Double.parseDouble(tokens[idx++]);
                    double y = Double.parseDouble(tokens[idx++]);
                    double z = Double.parseDouble(tokens[idx++]);
                    poly.verts.add(new Point3D(x, y, z));
                }
                polygons.add(poly);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    // Rotate around X, then Y, then scale, then shift
    private Point3D transform(Point3D p) {
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        double rx = Math.toRadians(rotateXDeg);
        double ry = Math.toRadians(rotateYDeg);

        // 1) rotate about X
        double cx = Math.cos(rx), sx = Math.sin(rx);
        double y1 = cx*y0 - sx*z0;
        double z1 = sx*y0 + cx*z0;
        double x1 = x0;

        // 2) rotate about Y
        double cy = Math.cos(ry), sy = Math.sin(ry);
        double z2 = cy*z1 - sy*x1;
        double x2 = sy*z1 + cy*x1;
        double y2 = y1;

        // 3) scale
        x2 *= scale;
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    private Point project(Point3D p, int width, int height) {
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0;
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth(), h = getHeight();
        for(Polygon3D poly : polygons) {
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D tpt = transform(poly.verts.get(i));
                Point p2 = project(tpt, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            g.drawPolygon(xp, yp, n);
        }
    }

    public static void main(String[] args) {
        if(args.length < 1) {
            System.out.println("Usage: java Interactive3DViewer <datafile>");
            System.exit(0);
        }
        new Interactive3DViewer(args[0]);
    }
}
