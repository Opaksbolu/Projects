import java.awt.*;
import java.awt.event.*;  // keep it
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;

public class Better3DViewer extends JFrame {
    private StringBuilder logBuilder = new StringBuilder();

    // We'll keep a minimal KeyEvent reference
    private KeyEvent exampleKeyEvent;

    static class Polygon3D {
        ArrayList<Point3D> verts = new ArrayList<>();
    }
    static class Point3D {
        double x, y, z;
        Point3D(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private ArrayList<Polygon3D> polygons;

    // Rotation angles (in degrees)
    private double rotateXDeg = 20.0;
    private double rotateYDeg = 35.0;

    private double cameraDist = 40.0;
    private double scale = 5.0; // enlarge shape

    // Shift the object so e.g. (5,5,5) is near origin
    private double shiftX = -5.0;
    private double shiftY = -5.0;
    private double shiftZ = -5.0;

    public Better3DViewer(String filename) {
        super("3D Viewer: Pyramid in a Cube");
        polygons = new ArrayList<>();
        readFile(filename);

        // Use a KeyEvent
        exampleKeyEvent = new KeyEvent(
            new Label("3DViewer"), 
            KeyEvent.KEY_TYPED, 
            System.currentTimeMillis(), 
            0, 
            KeyEvent.VK_UNDEFINED, 
            'v'
        );
        logBuilder.append("Better3DViewer: KeyEvent char='" + exampleKeyEvent.getKeyChar() + "'\n");

        // Window listener
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                logBuilder.append("Better3DViewer closing.\n");
                System.out.println(logBuilder.toString());
                System.exit(0);
            }
        });
        logBuilder.append("Better3DViewer constructor invoked.\n");

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void readFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            int numPolys = Integer.parseInt(br.readLine().trim());
            logBuilder.append("Reading " + numPolys + " polygons from " + filename + "\n");
            for(int i=0; i<numPolys; i++){
                String line = br.readLine().trim();
                String[] tokens = line.split("\\s+");
                int nVerts = Integer.parseInt(tokens[0]);
                Polygon3D poly = new Polygon3D();
                int idx = 1;
                for(int v=0; v<nVerts; v++){
                    double x = Double.parseDouble(tokens[idx++]);
                    double y = Double.parseDouble(tokens[idx++]);
                    double z = Double.parseDouble(tokens[idx++]);
                    poly.verts.add(new Point3D(x, y, z));
                }
                polygons.add(poly);
            }
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    // Rotate around X, then Y, then scale, then shift
    private Point3D rotateAndScale(Point3D p) {
        double x0 = p.x + shiftX;
        double y0 = p.y + shiftY;
        double z0 = p.z + shiftZ;

        double rx = Math.toRadians(rotateXDeg);
        double ry = Math.toRadians(rotateYDeg);

        // 1) Rotate about X
        double cX = Math.cos(rx), sX = Math.sin(rx);
        double y1 = cX*y0 - sX*z0;
        double z1 = sX*y0 + cX*z0;
        double x1 = x0;

        // 2) Rotate about Y
        double cY = Math.cos(ry), sY = Math.sin(ry);
        double z2 = cY*z1 - sY*x1;
        double x2 = sY*z1 + cY*x1;
        double y2 = y1;

        // 3) Scale
        x2 *= scale;
        y2 *= scale;
        z2 *= scale;

        return new Point3D(x2, y2, z2);
    }

    // Perspective projection
    private Point project(Point3D p, int width, int height) {
        double factor = cameraDist / (cameraDist - p.z);
        double px = p.x * factor;
        double py = p.y * factor;
        double sx = px + width/2.0;
        double sy = -py + height/2.0;
        return new Point((int)Math.round(sx), (int)Math.round(sy));
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        int w = getWidth();
        int h = getHeight();

        for (Polygon3D poly : polygons) {
            int n = poly.verts.size();
            int[] xp = new int[n];
            int[] yp = new int[n];
            for(int i=0; i<n; i++){
                Point3D r3 = rotateAndScale(poly.verts.get(i));
                Point p2 = project(r3, w, h);
                xp[i] = p2.x;
                yp[i] = p2.y;
            }
            g.drawPolygon(xp, yp, n);
        }
    }

    public static void main(String[] args) {
        if(args.length < 1) {
            System.out.println("Usage: java Better3DViewer <datafile>");
            System.exit(0);
        }
        new Better3DViewer(args[0]);
    }
}
