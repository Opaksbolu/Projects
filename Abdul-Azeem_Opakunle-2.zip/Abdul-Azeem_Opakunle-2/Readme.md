README: Multi-Segment Staircase

Overview

This project provides a 3D interactive Java application that generates a multi‐segment (e.g., L‐shaped) staircase—including a landing—and displays it in a window. The user can drag with the mouse to rotate the staircase from any angle.

Key Points:

It uses a simple hidden‐surface approach (z‐sort) for a 3D effect.
It fills the stairs with a single neutral color, with black outlines.
You can easily modify the code to change the number of segments, the geometry (tread, rise, width), or even add more landings.
By default, the code demonstrates an L‐shaped configuration with 5 steps, a landing, then 5 more steps at 90°.
Files

MultiSegmentStairs.java
Main Java source file that:
Builds an example two‐segment (L‐shaped) staircase with one landing.
Opens a GUI window with mouse‐drag 3D rotation.
Uses simple perspective projection and back‐to‐front z‐sorting for hidden‐surface rendering.
(Optional) README (this file)
Explains usage and how to modify the code for your desired layout.
No external data files are required. The geometry is generated entirely in code.

Requirements

Java 8 or higher installed.
A terminal/command prompt (or IDE) to compile and run the .java file.
Setup & Compilation

Extract the code (MultiSegmentStairs.java) into a directory of your choice.
Open a terminal (or use an IDE) in that directory.
Compile:
javac MultiSegmentStairs.java
If successful, you’ll see MultiSegmentStairs.class appear.
Running the Application

Simply run:

java MultiSegmentStairs
A window will appear, showing an L‐shaped staircase with 5 steps, a landing, then 5 more steps at a 90° turn.
Click and drag in the window to rotate the 3D view.
If you see any errors, ensure your Java environment is properly set up.
Customizing the Stairs

Inside MultiSegmentStairs.java, look for the method:

private void buildStaircaseExample() {
    ...
}
Here are some key changes you can make:

Number of Steps
Adjust n1 and n2 for each run.
Tread, Rise, Width
Adjust tread1, rise1, width1 (and similarly for the second run).
Landing
In addLanding(), you can change the landing’s tread dimension (e.g., make it bigger).
Angle Between Runs
The second segment is rotated by segmentTurnDeg = 90.0;
Change it to 180° for a U‐shape, 45° for a diagonal shape, etc.
Extra Segments
If you need more than 2 runs, just call buildSegment(), addLanding() repeatedly.
Colors & Appearance
fillColor = Color.LIGHT_GRAY; – switch to any color you like.
If you want to see a wireframe only, comment out the “fillPolygon” lines and just draw the edges.
For more advanced shapes (like fan/winder steps, curved treads, multiple landings, etc.), you can similarly adapt the corner definitions or the segmentation logic.

Troubleshooting

Window doesn’t open: Ensure your Java version is up to date and you compiled with no errors.
Shape offscreen or too big: Edit the lines:
private double cameraDist = 80.0;
private double scale = 6.0;
Increase cameraDist or decrease scale if shape is too large or clipped.
Want a single straight run: Just comment out the second run and landing calls in buildStaircaseExample() so it only calls buildSegment() once.
Misaligned steps: Check that your tread and rise values match what you need, and that the rotation angles are correct for each segment.