import java.awt.*;
import javax.swing.*;
import java.util.Random;

public class Tree extends JPanel {
    private final int maxDepth = 11;
    private final double baseLen = 120;
    private final double angle = Math.toRadians(30);
    private final double scale = 0.72;
    private final Random rng = new Random();

    public Tree() {
        setPreferredSize(new Dimension(800, 800));
        setBackground(Color.WHITE);
    }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int x = getWidth() / 2;
        int y = getHeight() - 60;
        drawBranch(g2, x, y, -Math.PI / 2, baseLen, maxDepth, 12f);
        g2.dispose();
    }

    private void drawBranch(Graphics2D g, double x1, double y1, double dir,
                            double len, int depth, float strokeW) {
        if (depth == 0 || len < 2) return;

        double x2 = x1 + len * Math.cos(dir);
        double y2 = y1 + len * Math.sin(dir);

        g.setStroke(new BasicStroke(strokeW, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(Color.BLACK);
        g.drawLine((int)x1, (int)y1, (int)x2, (int)y2);

        double randAngle = angle + (rng.nextDouble()-0.5)*Math.toRadians(10);
        double randLen   = len * (scale + (rng.nextDouble()-0.5)*0.1);

        drawBranch(g, x2, y2, dir - randAngle, randLen, depth-1, strokeW*0.7f);
        drawBranch(g, x2, y2, dir + randAngle, randLen, depth-1, strokeW*0.7f);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Natural Fractal Tree");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.add(new Tree());
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        });
    }
}
