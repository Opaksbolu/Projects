import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;

public class Gradient extends JPanel {
    public Gradient() {
        setPreferredSize(new Dimension(800, 600));
        setBackground(Color.WHITE);
    }

    private Shape createALetter(Font font, float x, float y) {
        FontRenderContext frc = new FontRenderContext(null, true, true);
        GlyphVector gv = font.createGlyphVector(frc, "A");
        Shape base = gv.getOutline();
        AffineTransform at = AffineTransform.getTranslateInstance(x, y);
        return at.createTransformedShape(base);
    }

    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Font big = new Font("Serif", Font.BOLD, 300);

        Shape a1 = createALetter(big, 50, 350);
        GradientPaint gp1 = new GradientPaint(0, 50, new Color(255, 0, 0),
                                              0, 350, new Color(255, 255, 0));
        g2.setPaint(gp1);
        g2.fill(a1);

        Shape a2 = createALetter(big, 200, 370);
        GradientPaint gp2 = new GradientPaint(0, 50, new Color(0, 0, 255, 180),
                                              0, 350, new Color(0, 255, 255, 180));
        g2.setPaint(gp2);
        g2.fill(a2);

        Shape a3 = createALetter(big, 350, 390);
        BufferedImage hatch = new BufferedImage(10, 10, BufferedImage.TYPE_INT_ARGB);
        Graphics2D ig = hatch.createGraphics();
        ig.setColor(new Color(0,0,0,0));
        ig.fillRect(0,0,10,10);
        ig.setColor(new Color(34,139,34,160));
        ig.fillRect(0,0,5,5);
        ig.fillRect(5,5,5,5);
        ig.dispose();
        TexturePaint tp = new TexturePaint(hatch, new Rectangle(0,0,10,10));
        g2.setPaint(tp);
        g2.fill(a3);

        g2.dispose();
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Gradient / Transparency / Texture – Letter A");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.add(new Gradient());
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        });
    }
}
