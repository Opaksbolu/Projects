import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.InputEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FractalGrammars extends Frame {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FractalGrammars <grammar-file>");
            System.exit(1);
        }
        new FractalGrammars(args[0]);
    }

    public FractalGrammars(String path) {
        super("L-System Fractal Viewer (click L/R)");
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { System.exit(0); }
        });
        setSize(800, 600);
        add("Center", new GrammarCanvas(path));
        setVisible(true);
    }

    static class GrammarCanvas extends Canvas {
        // L-system definitions
        private String grammarAxiom, ruleFq, ruleFf, ruleX, ruleY, ruleU, ruleV;
        // Turtle parameters
        private double turnAngle, initialAngle, startXFrac, startYFrac;
        private double baseStepFrac, shrinkFactor;
        private int recursionLevel = 1;
        // Drawing state
        private int canvasW, canvasH;
        private double currX, currY, currAngle, lastAngle, stepSize;
        private boolean justTurned = false;

        public GrammarCanvas(String filePath) {
            // Read 7 strings + 6 numbers
            ArrayList<String> data = new ArrayList<>();
            try (BufferedReader r = new BufferedReader(new FileReader(filePath))) {
                String ln;
                while (data.size() < 13 && (ln = r.readLine()) != null) {
                    int cpos = ln.indexOf("//");
                    String part = (cpos >= 0 ? ln.substring(0, cpos) : ln).trim();
                    if (!part.isEmpty()) data.add(part);
                }
            } catch (IOException ex) {
                System.err.println("Error reading file: " + ex.getMessage());
                System.exit(2);
            }
            if (data.size() < 13) {
                System.err.println("File must have 7 strings then 6 numbers.");
                System.exit(3);
            }

            // Extract L-system grammar strings (strip quotes if present)
            grammarAxiom = stripQuotes(data.get(0));
            ruleFq       = stripQuotes(data.get(1));
            ruleFf       = stripQuotes(data.get(2));
            ruleX        = stripQuotes(data.get(3));
            ruleY        = stripQuotes(data.get(4));
            ruleU        = stripQuotes(data.get(5));
            ruleV        = stripQuotes(data.get(6));

            // Extract numeric parameters
            turnAngle    = Double.parseDouble(data.get(7));
            initialAngle = Double.parseDouble(data.get(8));
            startXFrac   = Double.parseDouble(data.get(9));
            startYFrac   = Double.parseDouble(data.get(10));
            baseStepFrac = Double.parseDouble(data.get(11));
            shrinkFactor = Double.parseDouble(data.get(12));

            // Mouse controls recursion depth
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    if ((e.getModifiers() & InputEvent.BUTTON3_MASK) != 0) {
                        recursionLevel = Math.max(1, recursionLevel - 1);
                    } else {
                        recursionLevel++;
                    }
                    repaint();
                }
            });
        }

        private static String stripQuotes(String s) {
            s = s.trim();
            if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1) {
                return s.substring(1, s.length() - 1);
            }
            return s;
        }

        private int toPixX(double x) { return (int)Math.round(x); }
        private int toPixY(double y) { return (int)Math.round(canvasH - y); }

        private void drawLine(Graphics g, double nx, double ny) {
            // If just turned, round off last 30% of step into a mini-arc
            if (justTurned && lastAngle != currAngle) {
                double radius = stepSize * 0.3;
                double radOld = Math.toRadians(lastAngle);
                double radNew = Math.toRadians(currAngle);

                // Straight remainder
                double midX = currX + (stepSize - radius)*Math.cos(radOld);
                double midY = currY + (stepSize - radius)*Math.sin(radOld);
                g.drawLine(toPixX(currX), toPixY(currY), toPixX(midX), toPixY(midY));

                // Two-segment arc approximation
                double arcX = midX + radius * Math.cos((radOld + radNew)/2);
                double arcY = midY + radius * Math.sin((radOld + radNew)/2);
                g.drawLine(toPixX(midX), toPixY(midY), toPixX(arcX), toPixY(arcY));

                currX = arcX; 
                currY = arcY;
            } else {
                g.drawLine(toPixX(currX), toPixY(currY), toPixX(nx), toPixY(ny));
                currX = nx;
                currY = ny;
            }
            lastAngle = currAngle;
            justTurned = true;
        }

        private void movePen(double nx, double ny) {
            currX = nx; currY = ny;
        }

        @Override
        public void paint(Graphics g) {
            Dimension d = getSize();
            canvasW = d.width - 1;
            canvasH = d.height - 1;

            // Compute actual step length
            stepSize = baseStepFrac * canvasH * Math.pow(shrinkFactor, recursionLevel - 1);

            g.setColor(Color.BLACK);
            currAngle = initialAngle;
            lastAngle = currAngle;
            justTurned = false;
            currX = startXFrac * canvasW;
            currY = startYFrac * canvasH;

            applyGrammar(g, grammarAxiom, recursionLevel, baseStepFrac * canvasH);
        }

        private void applyGrammar(Graphics g, String seq, int depth, double len) {
            double saveX=0, saveY=0, saveA=0;
            for (int i = 0; i < seq.length(); i++) {
                char cmd = seq.charAt(i);
                switch (cmd) {
                    case 'F' -> {
                        if (depth == 0) {
                            double r = Math.toRadians(currAngle);
                            drawLine(g, currX + len*Math.cos(r), currY + len*Math.sin(r));
                        } else {
                            applyGrammar(g, ruleFq, depth-1, shrinkFactor*len);
                        }
                    }
                    case 'f' -> {
                        if (depth == 0) {
                            double r = Math.toRadians(currAngle);
                            movePen(currX + len*Math.cos(r), currY + len*Math.sin(r));
                        } else {
                            applyGrammar(g, ruleFf, depth-1, shrinkFactor*len);
                        }
                    }
                    case 'X' -> { if (depth>0) applyGrammar(g, ruleX, depth-1, shrinkFactor*len); }
                    case 'Y' -> { if (depth>0) applyGrammar(g, ruleY, depth-1, shrinkFactor*len); }
                    case 'U' -> { if (depth>0) applyGrammar(g, ruleU, depth-1, shrinkFactor*len); }
                    case 'V' -> { if (depth>0) applyGrammar(g, ruleV, depth-1, shrinkFactor*len); }
                    case '+' -> currAngle -= turnAngle;
                    case '-' -> currAngle += turnAngle;
                    case '[' -> { saveX=currX; saveY=currY; saveA=currAngle; justTurned=false; }
                    case ']' -> { currX=saveX; currY=saveY; currAngle=saveA; justTurned=false; }
                }
            }
        }
    }
}
