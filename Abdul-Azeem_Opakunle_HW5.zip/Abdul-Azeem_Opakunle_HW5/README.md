# CS4361 Assignment 5 – Java Graphics Programs

**Files**

| File               | Problem | Description |
|--------------------|---------|-------------|
| `DragonCurves.java`| 8.1     | 8‑generation Dragon Curve using rounded stroke joins/caps. |
| `Gradient.java`    | 7.3     | Three overlapping letter A’s showing transparency, gradient, and texture. |
| `Tree.java`        | 8.3     | Natural‑style fractal tree with randomised branches and varying thickness. |
| `Dragon.txt`       | —       | Sample grammar parameters. |

**Compile**

```bash
javac DragonCurves.java Gradient.java Tree.java
```

**Run**

```bash
java DragonCurves
java Gradient
java Tree
```