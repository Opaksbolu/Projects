import java.awt.*;
import java.awt.event.*;

public class square extends Frame {
    private Point A = null;
    private Point B = null;

    public static void main(String[] args) {
        square sq = new square();
        sq.setSize(600, 600);
        sq.setTitle("Draw CCW Square: A -> D -> C -> B");
        sq.setVisible(true);
    }

    public square() {
        // Capture mouse clicks
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                // First click sets A, second click sets B, third click resets.
                if (A == null) {
                    A = e.getPoint();
                } else if (B == null) {
                    B = e.getPoint();
                    repaint();
                } else {
                    // Reset for a new square
                    A = e.getPoint();
                    B = null;
                    repaint();
                }
            }
        });
    }

    @Override
    public void paint(Graphics g) {
        // Draw A in RED
        if (A != null) {
            g.setColor(Color.RED);
            g.fillOval(A.x - 4, A.y - 4, 8, 8);
            g.drawString("A", A.x - 15, A.y - 15);
        }
        // Draw B in BLUE
        if (B != null) {
            g.setColor(Color.BLUE);
            g.fillOval(B.x - 4, B.y - 4, 8, 8);
            g.drawString("B", B.x + 10, B.y - 10);
        }

        // Once A and B exist, compute D and C so that A->D->C->B is CCW.
        if (A != null && B != null) {
            int dx = B.x - A.x;
            int dy = B.y - A.y;

            // Use (dy, -dx) so that the polygon A->D->C->B->A is CCW.
            Point D = new Point(A.x + dy, A.y - dx);
            Point C = new Point(B.x + dy, B.y - dx);

            // Draw D in MAGENTA
            g.setColor(Color.MAGENTA);
            g.fillOval(D.x - 4, D.y - 4, 8, 8);
            g.drawString("D", D.x - 15, D.y - 15);

            // Draw C in GREEN
            g.setColor(Color.GREEN);
            g.fillOval(C.x - 4, C.y - 4, 8, 8);
            g.drawString("C", C.x + 10, C.y - 10);

            // Draw edges A->D->C->B->A with arrowheads
            g.setColor(Color.BLACK);
            drawArrowLine(g, A.x, A.y, D.x, D.y);  // Edge A->D
            drawArrowLine(g, D.x, D.y, C.x, C.y);  // Edge D->C
            drawArrowLine(g, C.x, C.y, B.x, B.y);  // Edge C->B
            drawArrowLine(g, B.x, B.y, A.x, A.y);  // Edge B->A
        }
    }

    /**
     * Draw a line with an arrowhead at (x2, y2), showing direction from (x1, y1) to (x2, y2).
     */
    private void drawArrowLine(Graphics g, int x1, int y1, int x2, int y2) {
        // Draw the main line
        g.drawLine(x1, y1, x2, y2);

        // Calculate the angle of the line
        double angle = Math.atan2(y2 - y1, x2 - x1);

        // Arrowhead configuration
        int arrowHeadLength = 10;
        double arrowAngle = Math.toRadians(20);

        // Endpoints for arrowhead lines
        int xArrow1 = (int)(x2 - arrowHeadLength * Math.cos(angle - arrowAngle));
        int yArrow1 = (int)(y2 - arrowHeadLength * Math.sin(angle - arrowAngle));
        int xArrow2 = (int)(x2 - arrowHeadLength * Math.cos(angle + arrowAngle));
        int yArrow2 = (int)(y2 - arrowHeadLength * Math.sin(angle + arrowAngle));

        // Draw arrowhead lines
        g.drawLine(x2, y2, xArrow1, yArrow1);
        g.drawLine(x2, y2, xArrow2, yArrow2);
    }
}
