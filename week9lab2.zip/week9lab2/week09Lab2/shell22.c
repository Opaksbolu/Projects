#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

#define MAX_COMMAND_LENGTH 1024
#define MAX_ARGS 32
void mysig_handler(int signo) {
    printf("\n ** This is the message from week09 lab2 - Signal Handler! ** \n");
    }
    void alarm_handler(int signo) {
        if (signo == SIGALRM) {
	        printf("\n ** Alarm is triggered! ** \n");
		        exit(0);
			    }
			    }
			    int main() {
			        char input[MAX_COMMAND_LENGTH];
				    char alarm_command[MAX_COMMAND_LENGTH];
				        struct sigaction sa;
					    sa.sa_handler = alarm_handler;
					        sigemptyset(&sa.sa_mask);
						    sa.sa_flags = 0;
						        if (sigaction(SIGALRM, &sa, NULL) == -1) {
							        perror("sigaction");
								        exit(1);
									    }

									        while (1) {
										        printf("shell22 > ");
											        fgets(input, sizeof(input), stdin);
												        input[strcspn(input, "\n")] = '\0';
													        if (strncmp(input, "alarm ", 6) == 0) {
														            strcpy(alarm_command, input + 6);
															                int n = atoi(alarm_command);
																	            if (n > 0) {
																		                    printf("Alarm is set for %d seconds.\n", n);
																				                    alarm(n);
																						                } else if (n == 0) {
																								                printf("Alarm is turned off.\n");
																										                alarm(0);
																												            } else {
																													                    printf("Invalid alarm value.\n");
																															                }
																																	        } else {
																																		            pid_t child_pid = fork();
																																			                if (child_pid == -1) {
																																					                perror("fork");
																																							                exit(EXIT_FAILURE);
																																									            } else if (child_pid == 0) {
																																										                    signal(SIGINT, mysig_handler);
																																												                    char *token;
																																														                    char *args[MAX_ARGS];
																																																                    int num_args = 0;
																																																		                    token = strtok(input, " ");
																																																				                    while (token != NULL) {
																																																						                        args[num_args] = token;
																																																									                    num_args++;
																																																											                        token = strtok(NULL, " ");
																																																														                }
																																																																                args[num_args] = NULL;
																																																																		                if (execvp(args[0], args) == -1) {
																																																																				                    perror("execvp");
																																																																						                        exit(EXIT_FAILURE);
																																																																									                }
																																																																											            } else {
																																																																												                    wait(NULL);
																																																																														                }
																																																																																        }
																																																																																	    }
																																																																																	        return 0;
																																																																																		}

