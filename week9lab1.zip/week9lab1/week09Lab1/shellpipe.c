#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_COMMANDS 5

void execute_command(char* command, int input_fd) {
    pid_t pid;
        if ((pid = fork()) == -1) {
	        perror("fork");
		        exit(1);
			    }

			        if (pid == 0) {
				        if (input_fd != 0) {
					            dup2(input_fd, 0);
						                close(input_fd);
								        }

									        char* args[64]; // adjust this as needed
										        int i = 0;
											        char* token = strtok(command, " ");
												        while (token != NULL) {
													            args[i++] = token;
														                token = strtok(NULL, " ");
																        }
																	        args[i] = NULL;

																		        execvp(args[0], args);
																			        perror("execvp");
																				        exit(1);
																					    } else {
																					            wait(NULL);
																						        }
																							}

																							int main() {
																							    char* commands[MAX_COMMANDS] = {
																							            "date",
																								            "ps",
																									            "ps -aux | grep ABO200001",
																										            "ls -l",
																											            "ls -l /etc | head -n 10"
																												        };

																													    int num_commands = 5;
																													        int input_fd = 0;

																														    int i; // Declare the loop variable outside of the loop in C89
																														        for (i = 0; i < num_commands; i++) {
																															        execute_command(commands[i], input_fd);
																																    }

																																        return 0;
																																	}

